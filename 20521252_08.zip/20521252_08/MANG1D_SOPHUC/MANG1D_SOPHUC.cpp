#include<iostream>
#include<iomanip>
#include<ctime>
#include<cmath>
#include<string>
using namespace std;

struct sophuc
{
	int thuc;
	int ao;
};
typedef struct sophuc SOPHUC;
void Nhap(SOPHUC&);
void Xuat(SOPHUC);
void Nhap(SOPHUC[], int&);
void Xuat(SOPHUC[], int);
SOPHUC Tong(SOPHUC, SOPHUC);
SOPHUC Tong(SOPHUC[], int);
SOPHUC DauTien(SOPHUC[], int);
void HoanVi(SOPHUC&, SOPHUC&);
void SapTang(SOPHUC[], int);

int main()
{
	SOPHUC a[100];
	int n;
	Nhap(a, n);
	Xuat(a, n);
	return 1;
}

void Nhap(SOPHUC& x)
{
	cout << "Nhap thuc: ";
	cin >> x.thuc;
	cout << "Nhap ao: ";
	cin >> x.ao;
}

void Xuat(SOPHUC x)
{
	cout << "\nThuc: " << x.thuc;
	cout << " ao: " << x.ao<<endl;
}

void Nhap(SOPHUC a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap phan a[" << i << "]: \n";
		Nhap(a[i]);
	}
}

void Xuat(SOPHUC a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "\na[" << i << "]: ";
		Xuat(a[i]);
	}
}

SOPHUC Tong(SOPHUC x, SOPHUC y)
{
	SOPHUC lc;
	lc.thuc = x.thuc + y.thuc;
	lc.ao = x.ao + y.ao;
	return lc;
}
SOPHUC Tong(SOPHUC a[], int n)
{
	if (n == 0)
		return { 0,0 };
	SOPHUC s=Tong(a, n - 1);
	s = Tong(s, a[n - 1]);
	return s;
}

SOPHUC DauTien(SOPHUC a[], int n)
{
	for (int i = 0; i < n; i++)
		if (a[i].thuc > 0 && a[i].ao > 0)
			return a[i];
	return { 0,0 };
}

void HoanVi(SOPHUC& x, SOPHUC& y)
{
	SOPHUC lc = x;
	x = y;
	y = lc;
}
void SapTang(SOPHUC a[], int n)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			if (a[i].thuc > a[j].thuc)
				HoanVi(a[i], a[j]);
}
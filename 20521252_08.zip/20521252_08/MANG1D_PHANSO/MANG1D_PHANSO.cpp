#include<iostream>
#include<iomanip>
#include<string>
#include<cmath>
#include<ctime>
using namespace std;

struct phanso
{
	int tu;
	int mau;
};
typedef struct phanso PHANSO;
void Nhap(PHANSO&);
void Xuat(PHANSO);
void Nhap(PHANSO[], int&);
void Xuat(PHANSO[], int);
bool ktDuong(PHANSO);
int DemDuong(PHANSO[], int);
bool SoSanh(PHANSO, PHANSO);
PHANSO LonNhat(PHANSO[], int);
int ViTriNhoNhat(PHANSO[], int);
PHANSO DuongDau(PHANSO[], int);
PHANSO DuongNhoNhat(PHANSO[], int);
bool ktAm(PHANSO);
int TimViTri(PHANSO[], int);
void HoanVi(PHANSO&, PHANSO&);
void SapTang(PHANSO[], int);

int main()
{
	PHANSO a[100];
	int n;
	Nhap(a, n);
	Xuat(a, n);
	return 1;
}

void Nhap(PHANSO& x)
{
	cout << "\nNhap tu: ";
	cin >> x.tu;
	cout << "Nhap mau: ";
	cin >> x.mau;
}

void Xuat(PHANSO x)
{
	cout << "Tu: " << x.tu;
	cout << " Mau: " << x.mau<<endl;
}

void Nhap(PHANSO a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap a[" << i << "]: ";
		Nhap(a[i]);
	}
}

void Xuat(PHANSO a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "\na[" << i << "]: \n";
		Xuat(a[i]);
	}
}

bool ktDuong(PHANSO x)
{
	if (x.tu*x.mau > 0 )
		return true;
	return false;
}
int DemDuong(PHANSO a[], int n)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (ktDuong(a[i]))
			dem++;
	return dem;
}

bool SoSanh(PHANSO x, PHANSO y)
{
	if (x.tu * y.mau > y.tu * x.mau)
		return true;
	return false;
}
PHANSO LonNhat(PHANSO a[], int n)
{
	PHANSO lc = a[0];
	for (int i = 0; i < n; i++)
	{
		if (SoSanh(a[i], lc))
			lc = a[i];
	}
	return lc;
}

int ViTriNhoNhat(PHANSO a[], int n)
{
	int lc = 0;
	for (int i = 0; i < n; i++)
		if (SoSanh(a[lc], a[i]))
			lc = i;
	return lc;
}

PHANSO DuongDau(PHANSO a[], int n)
{
	for (int i = 0; i < n; i++)
		if (ktDuong(a[i]))
			return a[i];
	return { 0,1 };
}

PHANSO DuongNhoNhat(PHANSO a[], int n)
{
	if (n == 0)
	{
		PHANSO lc = { -1,1 };
		return lc;
	}
	PHANSO lc = DuongNhoNhat(a, n-1);
	if (!ktDuong(a[n - 1]))
		return lc;
	if (!ktDuong(lc))
		return a[n - 1];
	if (SoSanh(lc, a[n - 1]))
		lc = a[n - 1];
	return lc;
}

bool ktAm(PHANSO x)
{
	if (x.tu * x.mau < 0)
		return true;
	return false;
}
int TimViTri(PHANSO a[], int n)
{
	if (n == 0)
		return -1;
	int lc = TimViTri(a, n - 1);
	if (!ktAm(a[n - 1]))
		return lc;
	if (!ktAm(a[lc]))
		return n - 1;
	if (SoSanh(a[n - 1], a[lc]))
		lc = n - 1;
	return lc;
}

void HoanVi(PHANSO& x, PHANSO& y)
{
	PHANSO lc = x;
	x = y;
	y = lc;
}
void SapTang(PHANSO a[], int n)
{
	for (int i = 0; i < n-1; i++)
		for (int j = i + 1; j < n; j++)
			if (SoSanh(a[i], a[j]))
				HoanVi(a[i], a[j]);
}
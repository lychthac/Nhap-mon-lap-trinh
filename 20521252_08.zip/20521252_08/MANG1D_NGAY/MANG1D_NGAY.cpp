#include<iostream>
#include<iomanip>
#include<ctime>
#include<cmath>
#include<string>
using namespace std;

struct ngay
{
	int ng;
	int th;
	int nm;
};
typedef struct ngay NGAY;
void Nhap(NGAY&);
void Xuat(NGAY);
void Nhap(NGAY[], int&);
void Xuat(NGAY[], int);
int Khoangcach(NGAY, NGAY);
void GanNhauNhat(NGAY[], int, NGAY&, NGAY&);
void XaNhauNhat(NGAY[], int, NGAY&, NGAY&);

int main()
{
	NGAY a[100];
	int n;
	Nhap(a, n);
	Xuat(a, n);
	return 1;
}

void Nhap(NGAY& x)
{
	cout << "\nNhap ngay: ";
	cin >> x.ng;
	cout << "Nhap thang: ";
	cin >> x.th;
	cout << "Nhap nam: ";
	cin >> x.nm;
}

void Xuat(NGAY x)
{
	cout << "\nNgay: " << x.ng;
	cout << "\nThang: " << x.th;
	cout << "\nNam: " << x.nm<<endl;
}

void Nhap(NGAY a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap a[" << i << "]: ";
		Nhap(a[i]);
	}
}

void Xuat(NGAY a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "\na[" << i << "]: ";
		Xuat(a[i]);
	}
}

int KhoangCach(NGAY x, NGAY y)
{
	if (x.nm < y.nm)
	{
		NGAY lc = x;
		x = y;
		y = lc;
	}
	if(x.nm>=y.nm)
	{
		if (x.th >= y.th)
		{
			if (x.ng >= y.ng)
				return (x.nm - y.nm) * 12 * 30 + (x.th - y.th) * 30 + x.ng - y.ng;
			return (x.nm - y.nm) * 12 * 30 + (x.th - y.th) * 30 + y.ng - x.ng;
		}
		else
		{
			if (x.ng >= y.ng)
				return (x.nm-y.nm)*12*30-(y.th-x.th)*30+x.ng-y.ng;
			return (x.nm-y.nm)*12*30-(y.th-x.th)*30+y.ng-x.ng ;
		}
	}
}
void GanNhauNhat(NGAY a[], int n, NGAY& x, NGAY& y)
{
	x = a[0];
	y = a[1];
	for(int i=0;i<n-1;i++)
		for(int j=i+1;j<n;j++)
			if (KhoangCach(a[i], a[j]) < KhoangCach(x, y))
			{
				x = a[i];
				y = a[j];
			}
	cout << "\n2 ngay gan nhua nhat la: ";
	Xuat(x);
	Xuat(y);
}

void XaNhauNhat(NGAY a[], int n, NGAY& x, NGAY& y)
{
	x = a[0];
	y = a[1];
	for(int i=0;i<n-1;i++)
		for(int j=i+1;j<n;j++)
			if (KhoangCach(a[i], a[j]) > KhoangCach(x, y))
			{
				x = a[i];
				y = a[j];
			}
	cout << "\n2 ngay xa nhau nhat la: ";
	Xuat(x);
	Xuat(y);
}
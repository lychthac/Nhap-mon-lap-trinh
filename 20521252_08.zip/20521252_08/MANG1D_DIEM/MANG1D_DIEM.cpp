#include<iostream>
#include<iomanip>
#include<string>
#include<cmath>
#include<ctime>
using namespace std;

struct diem
{
	float x;
	float y;
};
typedef struct diem DIEM;
void Nhap(DIEM&);
void Xuat(DIEM);
void Nhap(DIEM[], int&);
void Xuat(DIEM[], int);
int DemDiem(DIEM[], int);
DIEM TungLonNhat(DIEM[], int);
float KhoangCachGoc(DIEM);
DIEM GanGocNhat(DIEM[], int);
float KhoangCach(DIEM, DIEM);
void GanNhauNhat(DIEM[], int, DIEM&, DIEM&);
int ktTrung(DIEM, DIEM);
int TanSuat(DIEM[], int, DIEM);
int DemDiem(DIEM[], int);


int main()
{
	DIEM a[100];
	int k;
	Nhap(a, k);
	cout << "\nMang ban dau la: \n";
	Xuat(a, k);
	return 0;
}

void Nhap(DIEM& P)
{
	cout << "Nhap x: ";
	cin >> P.x;
	cout << "Nhap y: ";
	cin >> P.y;
}

void Xuat(DIEM P)
{
	cout << " x= " << P.x;
	cout << " y= " << P.y;
}

void Nhap(DIEM a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "Nhap diem a[" << i << "]: \n";
		Nhap(a[i]);
	}
}

void Xuat(DIEM a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "\nDiem a[" << i << "]: ";
		Xuat(a[i]);
	}
}

int DemDiem(DIEM a[], int n)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (a[i].x > 0)
			dem++;
	return dem;
}

DIEM TungLonNhat(DIEM a[], int n)
{
	DIEM lc = a[0];
	for (int i = 0; i < n; i++)
		if (a[i].y > lc.y)
			lc = a[i];
	return lc;
}

float KhoangCachGoc(DIEM P)
{
	return sqrt(P.x * P.x + P.y * P.y);
}
DIEM GanGocNhat(DIEM a[], int n)
{
	DIEM lc = a[0];
	for (int i = 0; i < n; i++)
		if (KhoangCachGoc(a[i])<KhoangCachGoc(lc))
			lc = a[i];
	return lc;
}

float KhoangCach(DIEM P, DIEM Q)
{
	return sqrt((P.x - Q.x) * (P.x - Q.x) + (P.y - Q.y) * (P.y - Q.y));
}
void GanNhauNhat(DIEM a[], int n, DIEM& P, DIEM& Q)
{
	P = a[0];
	Q = a[1];
	for(int i=0;i<n;i++)
		for(int j=i+1;j<n-1;j++)
			if (KhoangCach(a[i], a[j]) < KhoangCach(P, Q))
			{
				P = a[i];
				Q = a[j];
			}
	cout << "\n2 diem gan nhau nhat la: \n";
	Xuat(P);
	Xuat(Q);
}

int ktTrung(DIEM P, DIEM Q)
{
	if (P.x==Q.x && P.y==Q.y)
		return 1;
	return 0;
}
int TanSuat(DIEM a[], int n, DIEM P)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (ktTrung(a[i],P)==1)
			dem++;
	return dem;
}
int DemDiem(DIEM a[], int n)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (TanSuat(a,n,a[i]) == 1)
			dem++;
	return dem;
}

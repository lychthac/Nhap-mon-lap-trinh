#include<iostream>
#include<iomanip>
#include<cmath>
#include<ctime>
#include<string>
using namespace std;

struct duongthang
{
	float a;
	float b;
	float c;
};
typedef struct duongthang DUONGTHANG;
struct diem
{
	float x;
	float y;
};
typedef struct diem DIEM;
void Nhap(DIEM&);
void Xuat(DIEM);
void Nhap(DUONGTHANG&);
void Xuat(DUONGTHANG);
void Nhap(DUONGTHANG[], int&);
void Xuat(DUONGTHANG[], int);
bool ktSongSong(DUONGTHANG, DUONGTHANG);
int ktSongSong(DUONGTHANG[], int);
int ktCapSongSong(DUONGTHANG[], int);
bool ktTrung(DUONGTHANG, DUONGTHANG);
int ktCapTrungNhau(DUONGTHANG[], int);
bool ktThuoc(DUONGTHANG, DIEM);
int ktQuaDiem(DUONGTHANG[], int, DIEM&);
float KhoangCach(DUONGTHANG, DIEM);
DUONGTHANG GanDiemNhat(DUONGTHANG[], int, DIEM&);
bool ktCat(DUONGTHANG, DUONGTHANG);
DIEM GiaoDiem(DUONGTHANG, DUONGTHANG);
int ktDongQuy(DUONGTHANG[], int);

int main()
{
	DUONGTHANG a[100];
	int n;
	DIEM P;
	Nhap(a,n);
	Xuat(a,n);
	return 1;
}

void Nhap(DIEM& P)
{
	cout << "\nNhap x: ";
	cin >> P.x;
	cout << "Nhap y: ";
	cin >> P.y;
}

void Xuat(DIEM P)
{
	cout << "x: " << P.x;
	cout << " y: " << P.y;
}

void Nhap(DUONGTHANG& d)
{
	cout << "\nNhap a: ";
	cin >> d.a;
	cout << "Nhap b: ";
	cin >> d.b;
	cout << "Nhap c: ";
	cin >> d.c;
}

void Xuat(DUONGTHANG d)
{
	cout << "\na= " << d.a;
	cout << "\nb= " << d.b;
	cout << "\nc= " << d.c;
	cout << "\nPhuong trinh duong thang: " << d.a << "x + " << d.b << "y + " << d.c << " = 0"<<endl;
}

void Nhap(DUONGTHANG a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap a[" << i << "]: ";
		Nhap(a[i]);
	}
}

void Xuat(DUONGTHANG a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "\na[" << i << "]: ";
		Xuat(a[i]);
	}
}

bool ktSongSong(DUONGTHANG d, DUONGTHANG e)
{
	if ((float)d.a / -d.b == (float)e.a / -e.b && (float)d.c / -d.b != (float)e.c / -d.b)
		return true;
	return false;
}
int ktSongSong(DUONGTHANG a[], int n)
{
	for (int i = 1; i < n; i++)
		if (!ktSongSong(a[i], a[0]))
			return 0;
	return 1;
}

int ktCapSongSong(DUONGTHANG a[], int n)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			if (ktSongSong(a[i], a[j]))
				return 1;
	return 0;
}

bool ktTrung(DUONGTHANG d, DUONGTHANG e)
{
	if (d.a / e.a == d.b / e.b && d.b / e.b == d.c / e.c)
		return true;
	return false;
}
int ktCapTrungNhau(DUONGTHANG a[], int n)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			if (ktTrung(a[i], a[j]))
				return 1;
	return 0;
}

bool ktThuoc(DUONGTHANG d, DIEM P)
{
	if (d.a * P.x + d.b * P.y + d.c == 0)
		return true;
	return false;
}
int ktQuaDiem(DUONGTHANG a[],int n, DIEM& P)
{
	cout << "\nNhap diem can xet: ";
	Nhap(P);
	for (int i = 0; i < n; i++)
		if (ktThuoc(a[i], P))
			return 1;
	return 0;
}

float KhoangCach(DUONGTHANG d, DIEM P)
{
	return abs(d.a * P.x + d.b * P.y + d.c) / sqrt(d.a * d.a + d.b * d.b);
}
DUONGTHANG GanDiemNhat(DUONGTHANG a[], int n, DIEM& P)
{
	cout << "\nNhap diem can xet: ";
	Nhap(P);
	DUONGTHANG lc = a[0];
	for (int i = 0; i < n; i++)
		if (KhoangCach(a[i], P) < KhoangCach(lc, P))
			lc = a[i];
	return lc;
}

bool ktCat(DUONGTHANG d, DUONGTHANG e)
{
	if (d.a / -d.b != e.a / -e.b)
		return true;
	return false;
}
DIEM GiaoDiem(DUONGTHANG d, DUONGTHANG e)
{
	DIEM lc;
	lc.x = ((d.c / d.b) - (e.c / e.b)) / ((-d.a / d.b) + (e.a / e.b));
	lc.y = (-d.a / d.b) * lc.x - (d.c / d.b);
	return lc;
}
int ktDongQuy(DUONGTHANG a[], int n)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
			if (ktCat(a[i], a[j]))
			{
				DIEM PP = GiaoDiem(a[i], a[j]);
				for (int k = 0; k < n; k++)
					if (ktThuoc(a[k], PP) && k != i && k != j)
						return 1;
			}
	return 0;
}

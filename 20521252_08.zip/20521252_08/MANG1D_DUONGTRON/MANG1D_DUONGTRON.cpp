#include<iostream>
#include<iomanip>
#include<string>
#include<cmath>
#include<ctime>
using namespace std;
struct diem
{
	float x;
	float y;
};
typedef struct diem DIEM;
struct duongtron
{
	DIEM I;
	float r;
};
typedef struct duongtron DUONGTRON;
void Nhap(DIEM& );
void Xuat(DIEM );
void Nhap(DUONGTRON& );
void Xuat(DUONGTRON );
void Nhap(DUONGTRON[], int&);
void Xuat(DUONGTRON[], int);
float KhoangCachGoc(DUONGTRON);
DUONGTRON GanGocNhat(DUONGTRON[], int);
int ktQuaGoc(DUONGTRON);
int ktTonTai(DUONGTRON[], int);
float KhoangCachOx(DUONGTRON);
DUONGTRON GanOxNhat(DUONGTRON[], int);
bool ktTiepXucOy(DUONGTRON);
int KiemTra(DUONGTRON[], int);
int TuongDoi(DUONGTRON, DUONGTRON);
int ktDoiMotCatNhau(DUONGTRON[], int);
void LietKe(DUONGTRON[], int);

int main()
{
	DUONGTRON a[100];
	int n;
	Nhap(a, n);
	Xuat(a, n);
	return 1;
}

void Nhap(DIEM& P)
{
	cout << "\nNhap x: ";
	cin >> P.x;
	cout << "Nhap y: ";
	cin >> P.y;
}

void Xuat(DIEM P)
{
	cout << " x= " << P.x;
	cout << " y= " << P.y;
}

void Nhap(DUONGTRON& c)
{
	cout << "\nNhap tam duong tron: ";
	Nhap(c.I);
	cout << "Nhap ban kinh duong tron: ";
	cin >> c.r;
}

void Xuat(DUONGTRON c)
{
	cout << "\nTam duong tron: ";
	Xuat(c.I);
	cout << "\nBan kinh duong tron: " << c.r;
}

void Nhap(DUONGTRON a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap a[" << i << "]: ";
		Nhap(a[i]);
	}
}

void Xuat(DUONGTRON a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << "\na[" << i << "]: ";
		Xuat(a[i]);
	}
}

float KhoangCachGoc(DUONGTRON c)
{
	return sqrt(c.I.x*c.I.x+c.I.y*c.I.y);
}
DUONGTRON GanGocNhat(DUONGTRON a[], int n)
{
	DUONGTRON lc = a[0];
	for (int i = 1; i < n; i++)
		if (KhoangCachGoc(a[i])< KhoangCachGoc(lc))
			lc = a[i];
	return lc;
}

int ktQuaGoc(DUONGTRON c)
{
	if (KhoangCachGoc(c) == c.r)
		return 1;
	return 0;
}
int ktTonTai(DUONGTRON a[], int n)
{
	int flag = 0;
	for (int i = 0; i < n; i++)
		if (ktQuaGoc(a[i]) == 1)
			flag = 1;
	return flag;
}

float KhoangCachOx(DUONGTRON c)
{
	if (abs(c.I.y)<c.r)
		return 0;
	return abs(abs(c.I.y) - c.r);
}
DUONGTRON GanOxNhat(DUONGTRON a[], int n)
{
	DUONGTRON lc = a[0];
	for (int i = 0; i < n; i++)
		if (KhoangCachOx(a[i])< KhoangCachOx(lc))
			lc = a[i];
	return lc;
}

bool ktTiepXucOy(DUONGTRON c)
{
	if (abs(c.I.x) == c.r)
		return true;
	return false;
}
int KiemTra(DUONGTRON a[], int n)
{
	int flag = 0;
	for (int i = 0; i < n; i++)
		if (ktTiepXucOy(a[i]))
			flag = 1;
	return flag;
}

int TuongDoi(DUONGTRON c, DUONGTRON d)
{
	float cd = sqrt((d.I.x - c.I.x) * (d.I.x - c.I.x) + (d.I.y - c.I.y) * (d.I.y - c.I.y));
	if (cd == c.r + d.r) //tiep xuc ngoai
		return 1;
	if (cd == c.r - d.r) //tiep xuc trong
		return 2;
	if (cd > c.r - d.r && cd < c.r + d.r) //cat
		return 3;
	return 4; //khong cat
}
int ktDoiMotCatNhau(DUONGTRON a[], int n)
{
	int flag = 1;
	for(int i=0;i<n-1;i++)
		for(int j=i+1;j<n;j++)
			if(TuongDoi(a[i],a[j])==4)
				flag=0;
	return flag;
}

void LietKe(DUONGTRON a[], int n)
{
	for(int i=0;i<n-1;i++)
		for(int j=i+1;j<n;j++)
			if (TuongDoi(a[i], a[j]) == 1 || TuongDoi(a[i], a[j]) == 2)
			{
				Xuat(a[i]);
				Xuat(a[j]);
			}
}
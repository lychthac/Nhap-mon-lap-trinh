
#include <iostream>
#include <ctime>
using namespace std;

void XoaViTri(float[], int&, int);
void XoaTrungX(float[], int&, int);
void Nhap(float[], int&, int&);
void Xuat(float[], int);

int main()
{
	float b[100];
	int k, y;
	Nhap(b, k, y);
	XoaTrungX(b, k, y);
	Xuat(b, k);
}

void Nhap(float a[], int& n, int& x)
{
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap n: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i <= n - 1; i++)
		cin >> a[i];
	//a[i] = -100.0 + (rand() / RAND_MAX / (100.0 - (-100.0)));
}

void XoaTrungX(float a[], int& n, int x)
{
	for (int i = n - 1; i >= 0; i--)
		if (a[i] == x)
			XoaViTri(a, n, i);
}


void XoaViTri(float a[], int& n, int k)
{
	for (int i = k; i <= n - 2; i++)
		a[i] = a[i + 1];
	n--;
}

void Xuat(float a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&, int[], int&);
void Xuat(int[], int, int[], int);
int TanSuat(int[], int, int);
void LietKe(int[], int, int[], int);

int main()
{
	int a[100], b[100];
	int n, m;
	Nhap(a, n, b, m);
	Xuat(a, n, b, m);
	cout << "\nCac gia tri xuat hien mot trong hai mang la: ";
	LietKe(a, n, b, m);
	return 1;
}

void Nhap(int a[], int& n, int b[], int& m)
{
	cout << "Nhap n: ";
	cin >> n;
	cout << "Nhap m: ";
	cin >> m;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = rand() % (200 + 1) - 100;
	for (int j = 0; j < m; j++)
		b[j] = rand() % (200 + 1) - 100;
}

void Xuat(int a[], int n, int b[], int m)
{
	cout << "\nMang a ban dau la: ";
	for (int i = 0; i < n; i++)
		cout << setw(6) << a[i];
	cout << "\nMang b ban dau la: ";
	for (int j = 0; j < m; j++)
		cout << setw(6) << b[j];
}

int TanSuat(int a[], int n, int x)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (a[i] == x)
			dem++;
	return dem;
}

void LietKe(int a[], int n, int b[], int m)
{
	for (int i = 0; i < n; i++)
	{
		int flag = 1;
		for (int j = 0; j < i; j++)
			if (a[j] == a[i])
				flag = 0;
		if (TanSuat(b, m, a[i]) == 0 && flag )
			cout<<setw(6)<<a[i];
	}
	for (int i = 0; i < m; i++)
	{
		int flag = 1;
		for (int j = 0; j < i; j++)
			if (b[j] == b[i])
				flag = 0;
		if (TanSuat(a, n, b[i]) == 0 && flag)
			cout<<setw(6)<<b[i];
	}
}
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&, int&);
void Xuat(int[], int);
void XuatCon(int[], int, int);

int main()
{
	int b[100];
	int k,l;
	Nhap(b, k,l);
	cout << "Mang ban dau la: ";
	Xuat(b, k);
	cout << "\nMang con la: ";
	XuatCon(b, k, l);
	return 1;
}

void Nhap(int a[], int& n,int& l)
{
	cout << "Nhap n: ";
	cin >> n;
	cout << "Nhap do dai: ";
	cin >> l;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % (200 + 1) - 100;
	}
}

void Xuat(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << a[i];
	}
}

void XuatCon(int a[], int n, int l)
{
	for (int vt = 0; vt <= n - l; vt++)
	{
		cout << endl;
		for (int i = 0; i < l; i++)
			cout << setw(4) << a[vt + i];
	}
}
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&, float[], int&);
void Xuat(float[], int, float[], int);
int ktCon(float[], int, float[], int);

int main()
{
	float a[100],b[100];
	int n,m;
	Nhap(a, n,b,m);
	Xuat(a,n,b,m);
	if (ktCon(a, n, b, m) == 1)
		cout << "\nMang a la mang con cua mang b";
	else
		cout << "\nMang a khong la mang con cua mang b";
	return 1;
}

void Nhap(float a[], int& n, float b[], int& m)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
	cout << "Nhap m: ";
	cin >> m;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		b[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n, float b[], int m)
{
	cout << "Mang a ban dau la: ";
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
	cout << "\nMang b ban dau la: ";
	for (int j = 0; j < m; j++)
	{
		cout << setw(6) << setprecision(3) << b[j];
	}
}

int ktCon(float a[], int n, float b[], int m)
{
	if (n > m)
		return 0;
	int flag = 0;
	for (int vt = 0; vt <= m - n; vt++)
	{
		int co = 1;
		for (int i = 0; i < n; i++)
			if (a[i] != b[vt + i])
				co = 0;
		if (co == 1)
			flag = 1;
	}
	return flag;
}
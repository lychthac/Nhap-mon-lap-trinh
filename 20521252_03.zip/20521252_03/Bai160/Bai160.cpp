#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&, int& x);
void Xuat(float[], int, int);
void XoaViTri(float[], int&, int);

int main()
{
	float b[100];
	int k;
	int x;
	Nhap(b, k, x);
	cout << "\nMang ban dau la :";
	Xuat(b, k, x);
	XoaViTri(b, k, x);
	cout << "\nMang sau khi xoa :";
	Xuat(b, k, x);
	return 1;
}
void Nhap(float a[], int& n, int& x)
{
	cout << "Nhap n : ";
	cin >> n;
	cout << "Nhap vi tri can xoa : ";
	cin >> x;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
	{
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
	}
}
void Xuat(float a[], int n, int x)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void XoaViTri(float a[], int& n, int k)
{
	for (int i = k; i <= n - 2; i++)
	{
		a[i] = a[i + 1];
	}
	n--;
}
void XoaAm(float a[], int& n)
{
	for (int i = n - 1; i >= 0; i++)
	{
		if (a[i] < 0)
			XoaViTri(a, n, i);
	}
}
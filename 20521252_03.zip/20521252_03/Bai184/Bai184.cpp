#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
int DemCon(float[], int, float[], int);

int main()
{
	float a[100],b[100];
	int n,m;
	Nhap(a,n);
	Nhap(b, m);
	cout << "Mang a ban dau la: ";
	Xuat(a, n);
	cout << "\nMang b ban dau la: ";
	Xuat(b, m);
	cout << "\nSo lan xuat hien la: " << DemCon(a, n, b, m);
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}

int DemCon(float a[], int n, float b[], int m)
{
	if (n > m)
		return 0;
	int dem = 0;
	for (int vt = 0; vt <= m - n; vt++)
	{
		int flag = 1;
		for (int i = 0; i < n; i++)
			if (a[i] != b[vt + i])
				flag = 0;
		if (flag == 1)
			dem++;
	}
	return dem;
}
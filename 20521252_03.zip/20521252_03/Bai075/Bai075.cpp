#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&, float&);
void Xuat(float[], int);
float XaNhat(float[], int, float);

int main()
{
	float b[100];
	int k;
	float x;
	Nhap(b, k, x);
	cout << "\nMang dau vao la: ";
	Xuat(b, k);
	cout << "\nGia tri xa gia tri x nhat la: " << XaNhat(b, k, x);
	return 1;
}

void Nhap(float a[], int& n, float& x)
{
	cout << "Nhap n: ";
	cin >> n;
	cout << "nhap x la: ";
	cin >> x;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}

float XaNhat(float a[], int n, float x)
{
	float lc = a[0];
	for (int i = 0; i < n; i++)
	{
		if (abs(a[i]-x) > abs(lc-x))
			lc = a[i];
	}
	return lc;
}
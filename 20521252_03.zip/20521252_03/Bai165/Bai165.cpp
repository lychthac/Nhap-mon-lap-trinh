
#include <iostream>
#include <ctime>
using namespace std;

void XoaViTri(float[], int&, int);
void XoaLonNhat(float[], int&);
float LonNhat(float[], int);
void Nhap(float[], int&);
void Xuat(float[], int);

int main()
{
	float b[100];
	int k;
	Nhap(b, k);
	XoaLonNhat(b, k);
	Xuat(b, k);
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i <= n - 1; i++)
		cin >> a[i];
	//a[i] = -100.0 + (rand() / RAND_MAX / (100.0 - (-100.0)));
}

void XoaLonNhat(float a[], int& n)
{
	float ln = LonNhat(a, n);
	for (int i = n - 1; i >= 0; i--)
		if (a[i] == ln)
			XoaViTri(a, n, i);
}


float LonNhat(float a[], int n)
{
	float lc = a[0];
	for (int i = 1; i <= n - 1; i++)
		if (a[i] > lc)
			lc = a[i];
	return lc;
}

void XoaViTri(float a[], int& n, int k)
{
	for (int i = k; i <= n - 2; i++)
		a[i] = a[i + 1];
	n--;
}

void Xuat(float a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}
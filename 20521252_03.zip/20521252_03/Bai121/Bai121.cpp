#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;


void Nhap(int[], int&);
void Xuat(int[], int);
bool ktHoanThien(int);
int ktTinhChat(int[], int);

int main()
{
	int b[100];
	int k;
	Nhap(b, k);
	cout << "Mang ban dau: ";
	Xuat(b, k);
	if (ktTinhChat(b,k) == 1)
		cout << "\nMang khong co ton tai so hoan thien lon hon 256";
	else
		cout << "\nMang ton tai so hoan thien lon hon 256";
	return 1;
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = rand() % (1000 + 1) - 500;
}

void Xuat(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << a[i];
	}
}

bool ktHoanThien(int n)
{
	int s = 0;
	for (int i = 1; i <= n / 2; i++)
		if (n % i == 0)
			s = s + i;
	if (s == n)
		return true;
	return false;
}

int ktTinhChat(int a[], int n)
{
	int dem = 0;
	for (int i = 0; i < n; i++)
		if (ktHoanThien(a[i]) && a[i] > 256)
			dem++;
	if (dem == 0)
		return 1;
	return 0;
}
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(float[], int&);
void Xuat(float[], int);
void SapTang(float[], int);
void HoanVi(float&, float&);
int ktHoanVi(float[], int, float[], int);



int main()
{
	float a[100];
	float b[100];
	int k;
	int l;
	Nhap(a, k);
	cout << "Mang thu nhat la: ";
	Xuat(a, k);
	Nhap(b, l);
	cout << "Mang thu hai la: ";
	Xuat(b, l);
	ktHoanVi(a, k, b, l);
	if (ktHoanVi(a, k, b, l) == 1)
		cout << "\nHai mang hoan vi";
	else
	    cout << "\nHai mang khong hoan vi";
	return 1;
}

void Nhap(float a[], int& n)
{
	cout << "\nNhap so phan tu : ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
	{
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
	}
}

void Xuat(float a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void HoanVi(float& x, float& y)
{
	float temp = x;
	x = y;
	y = temp;
}
void SapTang(float a[], int n)
{
	for (int i = 0; i <= n - 2; i++)
		for (int j = i + 1; j <= n - 1; j++)
			if (a[i] > 0 && a[j] > 0 && a[i] > a[j])
				HoanVi(a[i], a[j]);
}
int ktHoanVi(float a[], int n, float b[], int m)
{
	if (m != n)
		return 0;
	SapTang(a, n);
	SapTang(b, m);
	int flag = 1;
	for (int i = 0; i < n; i++)
	{
		if (a[i] != b[i])
			flag = 0;
	}
	return flag;
}



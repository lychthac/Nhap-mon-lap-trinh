#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&);
void Xuat(int[], int);
void HoanVi(int&, int&);
void ChanTang(int[], int);
void LeTang(int[], int);
void ChanTangLeTang(int[], int);


int main()
{
	int b[100];
	int k;
	Nhap(b, k);
	cout << "Mang ban dau la :";
	Xuat(b, k);
	cout << "\nMang sau sap xep :";
	ChanTangLeTang(b, k);
	Xuat(b, k);
	return 1;
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n : ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
	{
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
	}
}
void Xuat(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << a[i];
	}
}
void HoanVi(int& x, int& y)
{
	int temp = x;
	x = y;
	y = temp;
}

void LeTang(int a[], int n)
{
	for (int i = 0; i <= n - 2; i++)
		for (int j = i + 1; j <= n - 1; j++)
			if (!a[i] % 2 && !a[j] % 2 && a[i] > a[j])
				HoanVi(a[i], a[j]);
}
void ChanTang(int a[], int n)
{
	for (int i = 0; i <= n - 2; i++)
		for (int j = i + 1; j <= n - 1; j++)
			if (a[i] % 2 && a[j] % 2 && a[i] > a[j])
				HoanVi(a[i], a[j]);
}
void ChanTangLeTang(int a[], int n)
{
	ChanTang(a, n);
	LeTang(a, n);
}
#include <iostream>
#include <ctime>
using namespace std;

void XoaViTri(int[], int&, int);
void XoaChinhPhuong(int[], int&);
bool ktChinhPhuong(int);
void Nhap(int[], int&);
void Xuat(int[], int);

int main()
{
	int b[100];
	int k;
	Nhap(b, k);
	XoaChinhPhuong(b, k);
	Xuat(b, k);
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i <= n - 1; i++)
		//cin >> a[i];
		a[i] = -100.0 + (rand() / RAND_MAX / (100.0 - (-100.0)));
}

void XoaChinhPhuong(int a[], int& n)
{
	for (int i = n - 1; i >= 0; i--)
		if (ktChinhPhuong(a[i]))
			XoaViTri(a, n, i);
}


bool ktChinhPhuong(int n)
{
	if (n < 0)
		return false;
	for (int i = 1; (i * i) <= n; i++)
		if (i * i == n)
			return true;
	return false;
}

void XoaViTri(int a[], int& m, int k)
{
	for (int i = k; i <= m - 2; i++)
		a[i] = a[i + 1];
	m--;
}

void Xuat(int a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}
#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
#include <fstream>
using namespace std;

void Nhap(string, float[], int&);
void Xuat(float[], int);

int main()
{
	float b[100];
	int k;
	string filename = "Bai004.txt";
	Nhap(filename, b, k);
	cout << "\nMang ban dau la: ";
	Xuat(b, k);
}

void Nhap(string filename, float a[], int& n)
{
	ifstream fi(filename);
	fi >> n;
	for (int i = 0; i <= n - 1; i++)
	{
		fi >> a[i];
	}
}

void Xuat(float a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
	{
		cout << setw(6) << a[i];
	}
}
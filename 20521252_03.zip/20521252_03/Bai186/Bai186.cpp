#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&,int&);
void Xuat(int[], int);
int TongCon(int[], int, int, int);
void TimCon(int[], int, int, int&, int&);

int main()
{
	int b[100];
	int k,m,vtd,vtc;
	Nhap(b, k,m);
	cout << "Mang ban dau la: ";
	Xuat(b, k);
	cout << "\nMang con co tong bang M la: ";
	TimCon(b, k, m, vtd, vtc);
	return 1;
}

void Nhap(int a[], int& n, int& m)
{
	cout << "Nhap n: ";
	cin >> n;
	cout << "Nhap M: ";
	cin >> m;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
	{
		a[i] = rand() % (200 + 1) - 100;
	}
}

void Xuat(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << a[i];
	}
}

int TongCon(int a[], int n, int vt, int l)
{
	int s = 0;
	for (int i = 0; i <= l - 1; i++)
		s = s + a[vt + i];
	return s;
}

void TimCon(int a[], int n, int M, int& vtd, int& vtc)
{
	for(int l=1;l<=n;l++)
		for (int vt = 0; vt <= n - l; vt++)
			if (TongCon(a, n, vt, l) == M)
			{
				vtd = vt;
				vtc = vt + l - 1;
				for (int i = vtd; i <= vtc; i++)
					cout << setw(6) << a[i];
				return;
			}
	cout << "Khong co";
}
#include <iostream>
#include <ctime>
using namespace std;

void XoaViTri(int[], int&, int);
void XoaChan(int[], int&);
void Nhap(int[], int&);
void Xuat(int[], int);

int main()
{
	int b[100];
	int k;
	Nhap(b, k);
	XoaChan(b, k);
	Xuat(b, k);
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i <= n - 1; i++)
		a[i] = -100.0 + (rand() / RAND_MAX / (100.0 - (-100.0)));
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
	cout << endl;
}

void XoaChan(int a[], int& n)
{
	for (int i = n - 1; 1 >= 0; i--)
		if (a[i] % 2 == 0)
			XoaViTri(a, n, i);
}

void XoaViTri(int a[], int& n, int k)
{
	for (int i = k; i <= n - 2; i++)
		a[i] = a[i + 1];
	n--;
}

void Xuat(int a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}
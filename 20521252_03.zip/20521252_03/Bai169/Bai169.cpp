#include <iostream>
using namespace std;

void Nhap(float[], int&, int&, int&);
void ThemViTri(float[], int&, float, int);
void Xuat(float[], int);

int main()
{
	float b[100];
	int y, k, i;
	Nhap(b, k, y, i);
	ThemViTri(b, k, y, i);
	Xuat(b, k);
}

void Nhap(float a[], int& n, int& x, int& k)
{
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap k: ";
	cin >> k;
	cout << "Nhap n: ";
	cin >> n;
	for (int i = 0; i <= n - 1; i++)
		cin >> a[i];
}

void ThemViTri(float a[], int& n, float x, int k)
{
	for (int i = n; i >= k + 1; i--)
		a[i] = a[i - 1];
	a[k] = x;
	n++;
}

void Xuat(float a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}
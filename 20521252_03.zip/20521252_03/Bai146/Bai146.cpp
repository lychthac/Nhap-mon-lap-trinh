#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&);
void Xuat(int[], int);
void SapTang(int[], int);
void HoanVi(int&, int&);
void Tron(int[], int, int[], int, int[], int&);



int main()
{
	int a[100];
	int b[100];
	int c[200];
	int k;
	int l;
	int p = 0;
	Nhap(a, k);
	cout << "\nMang thu nhat la :";
	Xuat(a, k);
	SapTang(a, k);
	cout << "\nMang sap xep tang : ";
	Xuat(a, k);
	cout << "\n";
	Nhap(b, l);
	cout << "\nMang thu hai la :";
	Xuat(b, l);
	SapTang(b, l);
	cout << "\nMang sap xep tang : ";
	Xuat(b, l);
	Tron(a, k, b, l, c, p);
	cout << "\nMang sau khi tron";
	Xuat(c, p);
	return 1;
}

void Nhap(int a[], int& n)
{
	cout << "Nhap so phan tu : ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
	{
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
	}
}

void Xuat(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}
void HoanVi(int& x, int& y)
{
	int temp = x;
	x = y;
	y = temp;
}
void SapTang(int a[], int n)
{
	for (int i = 0; i <= n - 2; i++)
		for (int j = i + 1; j <= n - 1; j++)
			if (a[i] > a[j])
				HoanVi(a[i], a[j]);
}
void Tron(int a[], int n, int b[], int m, int c[], int& p)
{
	int i = 0;
	int j = 0;
	while (!(i >= n && j >= m))
	{
		if ((i < n && j < m && a[i] < b[j]) || (j >= m))
			c[p++] = a[i++];
		else
			c[p++] = b[j++];
	}
}


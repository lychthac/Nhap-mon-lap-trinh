#include <cstdlib>
#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;

void Nhap(int[], int&, int&, int&);
void Xuat(int[], int);
int DauTien(int[], int, int, int);

int main()
{
	int b[100];
	int k,x,y;
	Nhap(b, k,x,y);
	cout << "\nMang ban dau la: ";
	Xuat(b, k);
	cout << "\nGia tri dau tien trong khoang la: " << DauTien(b, k,x,y);
	return 1;
}

void Nhap(int a[], int& n, int& x, int& y)
{
	cout << "Nhap n: ";
	cin >> n;
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap y: ";
	cin >> y;
	srand(time(nullptr));
	for (int i = 0; i < n; i++)
		a[i] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(int a[], int n)
{
	for (int i = 0; i < n; i++)
	{
		cout << setw(6) << setprecision(3) << a[i];
	}
}

int DauTien(int a[], int n,int x,int y)
{
	for (int i = 0; i < n; i++)
		if (a[i] > x && a[i] < y)
			return a[i];
	return x;
}
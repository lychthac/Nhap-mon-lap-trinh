#include <iostream>
#include <ctime>
using namespace std;

void XoaViTri(int[], int&, int);
void XoaNguyenTo(int[], int&);
bool ktNguyenTo(int);
void Nhap(int[], int&);
void Xuat(int[], int);

int main()
{
	int b[100];
	int k;
	Nhap(b, k);
	XoaNguyenTo(b, k);
	Xuat(b, k);
}

void Nhap(int a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i <= n - 1; i++)
		cin >> a[i];
	//a[i] = -100.0 + (rand() / RAND_MAX / (100.0 - (-100.0)));
}

void XoaNguyenTo(int a[], int& n)
{
	for (int i = n - 1; i >= 0; i--)
		if (ktNguyenTo(a[i]))
			XoaViTri(a, n, i);
}


bool ktNguyenTo(int n)
{
	if (n < 2)
		return false;
	for (int i = 2; i <= sqrt(n); i++)
		if (n % i == 0)
			return false;
	return true;
}

void XoaViTri(int a[], int& n, int k)
{
	for (int i = k; i <= n - 2; i++)
		a[i] = a[i + 1];
	n--;
}

void Xuat(int a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}


#include <iostream>
#include <ctime>
using namespace std;

void XoaViTri(float[], int&, int);
void XoaTrung(float[], int&);
void Nhap(float[], int&);
void Xuat(float[], int);

int main()
{
	float b[100];
	int k;
	Nhap(b, k);
	XoaTrung(b, k);
	Xuat(b, k);
}

void Nhap(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i <= n - 1; i++)
		cin >> a[i];
	//a[i] = -100.0 + (rand() / RAND_MAX / (100.0 - (-100.0)));
}

void XoaTrung(float a[], int& n)
{

	for (int i = n - 1; i >= 1; i--)
	{
		int flag = 0;
		for (int j = i - 1; j >= 0; j--)
			if (a[j] == a[i])
			{
				XoaViTri(a, n, j);
				flag++;
			}
		if (flag > 0)
		{
			i = i - flag;
			XoaViTri(a, n, i);
		}

	}
}


void XoaViTri(float a[], int& n, int k)
{
	for (int i = k; i <= n - 2; i++)
		a[i] = a[i + 1];
	n--;
}

void Xuat(float a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}
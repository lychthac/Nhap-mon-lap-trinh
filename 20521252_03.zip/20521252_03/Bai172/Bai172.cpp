#include <iostream>
using namespace std;

void NhapGiam(float[], int&);
void Xuat(float[], int);

int main()
{
	float b[100];
	int k;
	NhapGiam(b, k);
	Xuat(b, k);
}

void NhapGiam(float a[], int& n)
{
	cout << "Nhap n: ";
	cin >> n;
	int x;
	cin >> a[0];
	for (int i = 1; i <= n - 1; i++)
	{
		cin >> x;
		int j = i - 1;
		while (j >= 0 && x < a[j])
		{
			a[j + 1] = a[j];
			j--;
		}
		a[j + 1] = x;
	}
}

void Xuat(float a[], int n)
{
	for (int i = 0; i <= n - 1; i++)
		cout << a[i] << " ";
}
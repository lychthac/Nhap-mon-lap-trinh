#include<iostream>
#include<cmath>
using namespace std;
float Tich(float);
int main()
{
	float x;
	cout << "Nhap gia tri cua x: ";
	cin >> x;
	float kq = Tich(x);
	cout << "Ket qua la: " << kq;
	return 0;
}
float Tich(float a)
{
	float a2 = a * a;
	float a4 = a2 * a2;
	float a6 = a4 * a2;
	return a6;
}
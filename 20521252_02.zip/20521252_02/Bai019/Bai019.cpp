#include<iostream>
#include<cmath>
using namespace std;
double Tich(float);
int main()
{
	float x;
	cout << "Nhap gia tri cua x: ";
	cin >> x;
	double kq = Tich(x);
	cout << "Ket qua la: " << kq;
	return 0;
}
double Tich(float a)
{
	float a2 = a * a;
	float a3 = a2 * a;
	float a6 = a3 * a3;
	double a12 = a6 * a6;
	double a13 = a12 * a;
	return a13;
}
#include<iostream>
#include<cmath>
using namespace std;
float Tong(float, int);
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = Tong(x, n);
	cout << "Tong la :" << kq;
	return 1;
}
float Tong(float y, int k)
{
	float t = y;
	for (int i = 1; i <= k; i++)
		t = t * (y+i);
	return t;
}

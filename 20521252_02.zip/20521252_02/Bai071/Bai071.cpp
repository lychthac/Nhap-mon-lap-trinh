#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
int main()
{
	float x;
	cout << "Nhap x = ";
	cin >> x;
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int kq = Tong(x, n);
	cout << "tong la : " << kq;
	return 1;
}
float Tong(float y, int k)
{
	float s = y;
	float t = y;
	for (int i = 1; i <= k; i++)
	{
		t = t * y * y;
		s = s + t;
	}
	return s;
}

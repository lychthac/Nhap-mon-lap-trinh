#include<iostream>
#include<cmath>
using namespace std;
float Tong();
int main()
{
	float kq = Tong();
	cout << "Tong la :" << kq;
	return 1;
}
float Tong()
{
	float s = 0;
	int i = 1;
	for (float e = 1; e >= pow(10,-6); i++)
	{
		e = (float)1 / i;
		s = s+e;
	}
	return s;
}
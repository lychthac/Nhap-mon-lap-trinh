#include<iostream>
#include<cmath>
using namespace std;
int DemUocChan(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int kq = DemUocChan(n);
	cout << "so luong uoc so chan la: " << kq;
	return 1;
}
int DemUocChan(int k)
{
	int s = 0;
	for (int i = 2; i <= k; i = i + 2)
	{
		if (k % i == 0)
			s = s + 1;
	}
	return s;
}
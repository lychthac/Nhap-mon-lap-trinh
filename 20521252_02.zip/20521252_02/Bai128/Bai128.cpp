#include <iostream>
#include <cmath>
using namespace std;
void XuatTang(int, int);
int main()
{
    int a, b;
    cout << " Nhap vao gia tri cua a va b lan luot la : ";
    cin >> a >> b;
    XuatTang(a, b);
    return 1;
}
void XuatTang(int x, int y)
{
    while (x > y)
    {
        int  temp = x;
        x = y;
        y = temp;
    }
    cout << " Hai so a va b theo thu tu tang dan la : " << x << " va " << y;
}

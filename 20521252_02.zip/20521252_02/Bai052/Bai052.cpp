#include<iostream>
#include<cmath>
using namespace std;
int DemUocSo(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int kq = DemUocSo(n);
	cout << "so luong uoc so la: " << kq;
	return 1;
}
int DemUocSo(int k)
{
	int t = k;
	int s = 0;
	for (int i = 1; i <= k; i++)
	{
		if (t % i == 0)
			s = s + 1;
	}
	return s;
}
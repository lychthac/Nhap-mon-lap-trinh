#include<iostream>
#include<cmath>
using namespace std;
void Nhap(float&, float&, float&, float&, float&, float&);
float KhoangCach(float, float, float, float);
float DienTich(float, float, float);
int main()
{
	float x1, y1, x2, y2, x3, y3;
	Nhap(x1, y1, x2, y2, x3, y3);

	float kcAB = KhoangCach(x1, y1, x2, y2);
	float kcBC = KhoangCach(x2, y2, x3, y3);
	float kcAC = KhoangCach(x3, y3, x1, y1);
	float dt = DienTich(kcAB, kcBC, kcAC);

	cout << "Dien tich tam giac la: " << dt;
	return 0;
}

void Nhap(float& x1, float& y1, float& x2, float& y2, float& x3, float& y3)
{
	cout << "Nhap x1= ";
	cin >> x1;
	cout << "Nhap y1= ";
	cin >> y1;
	cout << "Nhap x2= ";
	cin >> x2;
	cout << "Nhap y2= ";
	cin >> y2;
	cout << "Nhap x3= ";
	cin >> x3;
	cout << "Nhap y3= ";
	cin >> y3;
}
float KhoangCach(float a, float b, float c, float d)
{
	float kc = sqrt(pow(a - c, 2) + pow(b - d, 2));
	return kc;
}
float DienTich(float a, float b, float c)
{
	float s = (float)1 / 4 * sqrt((a + b + c) * (a + b - c) * (a - b + c) * (-a + b + c));
	return s;
}
#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
int main()
{
	int n;
	cout << "nhap n :";
	cin >> n;
	float x;
	cout << "Nhap x :";
	cin >> x;
	float kq = Tong(x, n);
	cout << "Tong la : " << kq;
	return 1;
}
float Tong(float y, int k)
{
	int s = 0;
	for (int i = 1; i <= k; i = i++)
		s = s + pow(i, y);
	return s;
}
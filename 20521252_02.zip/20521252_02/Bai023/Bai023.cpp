#include<iostream>
#include<cmath>
using namespace std;
void SoHangChuc(int&);
int main()
{
	int n;
	cout << "Nhap n: ";
	cin >> n;
	SoHangChuc(n);
	cout << "Chu so hang chuc la: " << n;
	return 0;
}
void SoHangChuc(int& a)
{
	a = (a / 10) % 10;
}
#include <iostream>
#include<cmath>
using namespace std;
int NhoNhat(int, int);
int main()
{
    int a, b;
    cout << " Nhap vao gia tri cua a va b lan luot la : ";
    cin >> a >> b;
    int kq = NhoNhat(a, b);
    cout << " Gia tri nho nhat la : " << kq;
    return 1;
}
int NhoNhat(int x, int y)
{
    int Min = x;
    while (y < Min)
        Min = y;
    return Min;
}
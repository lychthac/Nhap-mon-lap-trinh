#include<iostream>
#include<cmath>
using namespace std;
float Tong(float, int);
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = Tong(x, n);
	cout << "tong la :" << kq;
	return 1;
}
float Tong(float y, int k)
{
	float t = 1;
	float s = 0;
	for (int i = 1; i <= k; i++)
	{
		t = t * y;
		s = s + sin(t);
	}
	return s;
}
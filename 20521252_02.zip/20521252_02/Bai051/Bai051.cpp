#include<iostream>
#include<cmath>
using namespace std;
float TichUocSo(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = TichUocSo(n);
	cout << "tich uoc so la: " << kq;
	return 1;
}
float TichUocSo(int k)
{
	int t = k;
	int s = 1;
	for (int i = 1; i <= k; i++)
	{
		if (t % i == 0)
			s = s * i;
	}
	return s;
}
#include<iostream>
#include<cmath>
using namespace std;
int TongUocChan(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int kq=TongUocChan(n);
	cout << "tong uoc so chan la: " << kq;
	return 1;
}
int TongUocChan(int k)
{
	int s=0;
	for (int i = 2; i <= k; i = i + 2)
	{
		if (k % i == 0)
			s = s + i;
	}
	return s;
}
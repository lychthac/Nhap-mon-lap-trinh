#include<iostream>
#include<cmath>
using namespace std;
float Tong(float);
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float kq = Tong(x);
	cout << "Tong la :" << kq;
	return 1;
}
float Tong(float y)
{
	float s = 1;
	float t = 1;
	int m = 1;
	int i = 1;
	for (float e = 1; e >= pow(10, -6); i++)
	{
		t = t * y;
		m = m * i;
		e = (float)t / m;
		s = s + e;
	}
	return s;
}
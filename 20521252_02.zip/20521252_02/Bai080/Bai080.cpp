#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
int main()
{
	float x;
	cout << "nhap x :";
	cin >> x;
	int n;
	cout << "Nhap n :";
	cin >> n;
	float kq = Tong(x, n);
	cout << "Tong la : " << kq;
	return 1;
}
float Tong(float y, int k)
{
	float t = 1;
	int s = 1;
	for (int i = 2; i <= k+1; i++)
	{
		t = t * y;
		s = s + t * i;
	}
	return s;
}
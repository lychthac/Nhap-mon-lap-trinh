#include<iostream>
#include<cmath>
using namespace std;
float ChuVi(float, int);
int main()
{
	float r;
	cout << "Nhap ban kinh r: ";
	cin >> r;
	int n;
	cout << "Nhap so canh cua da giac deu: ";
	cin >> n;
	float kq = ChuVi(r, n);
	cout << "Chu vi da giac deu noi tiep hinh tron la: " << kq;
	return 0;
}
float ChuVi(float a, int b)
{
	float p = 2 * a * b * sin(3.14 / b);
	return p;
}
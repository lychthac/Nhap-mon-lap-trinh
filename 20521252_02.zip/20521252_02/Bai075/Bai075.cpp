#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
int main()
{
	float x;
	cout << "Nhap x: ";
	cin >> x;
	int n;
	cout << "nhap n :";
	cin >> n;
	float kq = Tong(x, n);
	cout << "ket qua la : " << kq;
	return 1;
}
float Tong(float y, int k)
{
	float t = 1;
	int m = 1;
	float s = 1;
	int i = 2;
	while (i <= 2 * k)
	{
		t = t * y * y;
		m = m * i * (i - 1);
		s = s + (float)t / m;
		i = i + 2;
	}
	return s;
}
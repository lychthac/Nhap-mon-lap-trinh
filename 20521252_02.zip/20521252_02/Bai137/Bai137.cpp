#include<iostream>
#include<cmath>
using namespace std;
float TinhGiaTri(float);

int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float kq = TinhGiaTri(x);
	cout << "gia tri cua ham so la:" << kq;
	return 1;
}

float TinhGiaTri(float k)
{
	float f;
	if (k >= 5)
		f = 2 * k * k + 5 * k + 9;
	else
		f = -2 * k * k + 4 * k - 9;
	return f;
}
#include <iostream>
#include<cmath>
using namespace std;
int bcnn(int, int);
int main()
{
    int a, b;
    cout << "nhap gia tri cua a, b lan luot la: ";
    cin >> a >> b;
    int kq = bcnn(a, b);
    cout << "boi chung nho nhat la: " << kq;
    return 0;
}
int bcnn(int x, int y)
{
    int m = x;
    int n = y;
    while (x * y != 0)
    {
        if (x > y)
            x = x - y;
        else 
            y = y - x;
    }
    int s = (m * n) / (x + y);
    return s;
}

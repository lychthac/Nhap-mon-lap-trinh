#include<iostream>
#include<cmath>
using namespace std;
float Tong(float, int);
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = Tong(x, n);
	cout << "tong la :" << kq;
	return 1;
}
float Tong(float y, int k)
{
	float s = 1-y;
	float t = y;
	int m = 1;
	int dau = 1;
	for (int i = 2; i <= 2*k+1; i=i+2)
	{
		t = t * y*y;
		m = m * i*(i+1);
		s = s + dau * (float)t / m;
		dau = -dau;
	}
	return s;
}
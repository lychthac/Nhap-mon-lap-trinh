#include <iostream>
#include <cmath>
using namespace std;
int ktChinhPhuong(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    int kq = ktChinhPhuong(n);
    if (kq==1)
        cout << "la so chinh phuong";
    else
        cout << "khong la so chinh phuong";
    return 0;
}
int ktChinhPhuong(int k)
{
    int flag = 0;
    int i = 0;
    while (i <= k)
    {
        if (i * i == k)
            flag = 1;
        i++;
    }
    return flag;
}
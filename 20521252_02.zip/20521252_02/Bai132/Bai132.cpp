#include<iostream>
#include<cmath>
using namespace std;
void Nhap(float&, float&, float&, float&, float&, float&, float&, float&);
float DienTich(float, float, float, float, float, float);
float ktThuoc(float, float, float, float);
int main()
{
	float xA, yA, xB, yB, xC, yC, xM, yM;
	Nhap(xA, yA, xB, yB, xC, yC, xM, yM);
	float sABC = DienTich(xA, yA, xB, yB, xC, yC);
	float sMAB = DienTich(xA, yA, xB, yB, xM, yM);
	float sMBC = DienTich(xB, yB, xC, yC, xM, yM);
	float sMCA = DienTich(xA, yA, xC, yC, xM, yM);
	float kq = ktThuoc(sABC, sMAB, sMBC, sMCA);
	if (kq == 1)
		cout << "Thuoc tam giac";
	else
		cout << "Khong thuoc tam giac";
	return 1;
}
float DienTich(float a, float b, float c, float d, float m, float n)
{
	return (float)1 / 2 * abs(a * d + c * n + m * b - c * b - m * d - a * n);
}
float ktThuoc(float a, float b, float c, float d)
{
	if (a==b+c+d)
		return 1;
	else
		return 0;
}
void Nhap(float& x1, float& y1, float& x2, float& y2, float& x3, float& y3, float& x4, float& y4)
{
	cout << "nhap xA = ";
	cin >> x1;
	cout << "nhap yA = ";
	cin >> y1;
	cout << "nhap xB = ";
	cin >> x2;
	cout << "nhap yB = ";
	cin >> y2;
	cout << "nhap xC = ";
	cin >> x3;
	cout << "nhap yC = ";
	cin >> y3;
	cout << "nhap xM = ";
	cin >> x4;
	cout << "nhap yM = ";
	cin >> y4;
}
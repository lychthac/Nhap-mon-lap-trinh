#include <iostream>
using namespace std;
int csdt(int);
int main()
{
	int n;
	cin >> n;
	int kq = csdt(n);
	cout <<"Chu so dau tien la: "<< kq;
	return 0;
}
int csdt(int k)
{
	while (k > 9)
		k = k / 10;
	return k;
}
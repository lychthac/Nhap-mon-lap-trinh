#include <iostream>
using namespace std;
int ktDang5n(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    if (ktDang5n(n) == 1)
        cout << "co dang 5^m";
    else
        cout << "khong co dang 5^m";
    return 0;
}
int ktDang5n(int k)
{
    int flag = 1;
    for (int t = k; t > 1; t = t / 5)
    {
        int dv = t % 5;
        if (dv != 0)
            flag = 0;
    }
    return flag;
}

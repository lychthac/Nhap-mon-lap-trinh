#include <iostream>
#include<cmath>
using namespace std;
int LonNhat(int, int);
int main()
{
    int a, b;
    cout << " Nhap vao gia tri cua a va b lan luot la : ";
    cin >> a >> b;
    int kq = LonNhat(a, b);
    cout << " Gia tri lon nhat la : " << kq;
    return 1;
}
int LonNhat(int x, int y)
{
    int Max = x;
    while (y > Max)
        Max = y;
    return Max;
}
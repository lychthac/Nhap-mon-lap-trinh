#include<iostream>
#include<cmath>
using namespace std;
float Tong(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = Tong(n);
	cout << "Tong la :" << kq;
	return 1;
}
float Tong(int k)
{
	float s = 0;
	for (int i = 1; i <= k; i++)
		s = s + (float)1/i;
	return s;
}
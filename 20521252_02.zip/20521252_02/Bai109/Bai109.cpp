#include<iostream>
#include<cmath>
using namespace std;
float Tong();
int main()
{
	float kq = Tong();
	cout << "hang so euler la :" << kq;
	return 1;
}
float Tong()
{
	float s = 1;
	int t = 1;
	int i = 1;
	for (float e = 1; e >= pow(10, -6); i++)
	{
		t = t * i;
		e = (float) 1/ t;
		s = s + e;
	}
	return s;
}
#include<iostream>
#include<cmath>
using namespace std;
int ktBatDangThuc(float, float, float);
int main()
{
	float x, y, z;
	cout << "nhap ba so x, y, z lan luot la: ";
	cin >> x >> y >> z;
	int kq = ktBatDangThuc(x, y, z);
	if (kq == 1)
		cout << "Bat dang thuc dung";
	else
		cout << "Bat dang thuc sai";
	return 1;
}
int ktBatDangThuc(float a, float b, float c)
{
	if (a <= b && b <= c)
		return 1;
	else
		return 0;
}
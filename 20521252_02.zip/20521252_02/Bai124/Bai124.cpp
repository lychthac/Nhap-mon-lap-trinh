#include <iostream>
#include<cmath>
using namespace std;
int TinhAn(int);
int TinhBn(int);
int main()
{
    int n;
    cout << " Nhap gia tri n la : ";
    cin >> n;
    int kq1 = TinhAn(n);
    int kq2 = TinhBn(n);
    cout << " So hang thu " << n << " cua day la : " << "\n a = " << kq1 << "\n b = " << kq2;
    return 1;
}
int TinhAn(int k)
{
    int at = 2;
    int bt = 1;
    int i = 2;
    int ahh, bhh;
    while (i <= k)
    {
        ahh = at * at + 2 * bt * bt;
        bhh = 2 * at * bt;
        at = ahh;
        bt = bhh;
        i++;
    }
    return ahh;
}
int TinhBn(int k)
{
    int at = 2;
    int bt = 1;
    int i = 2;
    int ahh, bhh;
    while (i <= k)
    {
        ahh = at * at + 2 * bt * bt;
        bhh = 2 * at * bt;
        at = ahh;
        bt = bhh;
        i++;
    }
    return bhh;
}
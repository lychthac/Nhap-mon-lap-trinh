#include<iostream>
using namespace std;
void HoanVi(int&, int&);
void Nhap (int&,int&);
void Xuat(int, int);
int main()
{
	int a, b;
	Nhap(a, b);
	HoanVi(a, b);
	Xuat(a, b);
	return 1;
}
void Xuat(int a, int b)
{
	cout << "Ket qua sau hoan vi: ";
	cout << "\n a = " << a;
	cout << "\n b = " << b;
}
void HoanVi(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

void Nhap(int& a, int& b)
{
	cout << "Nhap a = ";
	cin >> a;
	cout << "Nhap b = ";
	cin >> b;
}
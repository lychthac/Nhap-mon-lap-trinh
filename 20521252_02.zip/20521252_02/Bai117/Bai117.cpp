#include<iostream>
#include<cmath>
using namespace std;
int TinhAn(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int kq = TinhAn(n);
	cout << "so hang thu " << n << " la: " << kq;
	return 1;
}
int TinhAn(int k)
{
	int att = -1;
	int at = 3;
	int t = 2;
	int ahh;
	for (int i = 2; i <= k; i++)
	{
		t = t * 2;
		ahh = 5 * t + 5 * at-att;
		att = at;
		at = ahh;
	}
	return at;
}
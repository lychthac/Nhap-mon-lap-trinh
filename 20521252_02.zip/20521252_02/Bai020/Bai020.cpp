#include<iostream>
#include<cmath>
using namespace std;
double Tich(float);
int main()
{
	float x;
	cout << "Nhap gia tri cua x: ";
	cin >> x;
	double kq = Tich(x);
	cout << "Ket qua la: " << kq;
	return 0;
}
double Tich(float a)
{
	float a3 = a * a * a;
	float a4 = a3 * a;
	double a7 = a3 * a4;
	double a14 = a7 * a7;
	return a14;
}
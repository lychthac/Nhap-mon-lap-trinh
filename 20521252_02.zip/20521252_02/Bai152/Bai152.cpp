#include <iostream>
using namespace std;
int ktDang3n(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    if (ktDang3n(n)==1)
        cout << "co dang 3^m";
    else
        cout << "khong co dang 3^m";
    return 0;
}
int ktDang3n(int k)
{
    int flag = 1;
    for(int t=k;t>1;t=t/3)
    {
        int dv = t % 3;
        if (dv != 0)
            flag = 0;
    }
    return flag;
}

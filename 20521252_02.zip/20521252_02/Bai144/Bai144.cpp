#include <iostream>
#include <cmath>
using namespace std;
int ktNguyenTo(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    int kq = ktNguyenTo(n);
    if (kq==2)
        cout << "la so nguyen to";
    else
        cout << "khong la so nguyen to";
    return 0;
}
int ktNguyenTo(int k)
{
    int dem = 0;
    int i = 1;
    while (i <= k)
    {
        if(k%i==0)
            dem++;
        i++;
    }
    return dem;
}
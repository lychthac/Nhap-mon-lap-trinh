#include<iostream>
#include<cmath>
using namespace std;
void LietKeUocSo(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	LietKeUocSo(n);
	return 1; 
}
void LietKeUocSo(int k)
{
	for (int i = 1; i <= k; i++)
	{
		if (k % i == 0)
			cout << i<<" ";
	}
}

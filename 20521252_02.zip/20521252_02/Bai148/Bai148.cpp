#include <iostream>
using namespace std;
int ktToanChan(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    int kq = ktToanChan(n);
    if (kq==1)
        cout << " Toan chan";
    else
        cout << " Khong toan chan";
    return 0;
}
int ktToanChan(int k)
{
    int flag = 1;
    for (int t = k; t != 0; t = t / 10)
    {
        int dv = t % 10;
        if (dv % 2 == 1)
             flag = 0;
    }
    return flag;
}
#include<iostream>
#include<cmath>
using namespace std;
float Tong(float);
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float kq = Tong(x);
	cout << "Tong la :" << kq;
	return 1;
}
float Tong(float y)
{
	float s = y;
	float t = y;
	int m = 1;
	int dau = -1;
	int i = 3;
	for (float e = 1; e >= pow(10, -6); i=i+2)
	{
		t = t *y*y;
		m = m * i * (i - 1);
		e = (float)t/m;
		s = s + dau*e;
		dau = -dau;
	}
	return s;
}
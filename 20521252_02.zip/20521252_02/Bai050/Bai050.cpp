#include<iostream>
#include<cmath>
using namespace std;
float TongUocSo(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq=TongUocSo(n);
	cout << "tong uoc so la: " << kq;
	return 1;
}
float TongUocSo(int k)
{
	int t = k;
	int s = 0;
	for (int i = 1; i <= k; i++)
	{
		if (t % i == 0)
			s = s + i;
	}
	return s;
}
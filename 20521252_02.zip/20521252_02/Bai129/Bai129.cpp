#include <iostream>
#include <cmath>
using namespace std;
void XuatTang(int, int, int);
int main()
{
    float a, b, c;
    cout << " Nhap vao gia tri cua a, b va c lan luot la : ";
    cin >> a >> b >> c;
    XuatTang(a, b, c);
    return 1;
}
void XuatTang(int x, int y, int z)
{
    int temp;
    if (x > y)
    {
        temp = x;
        x = y;
        y = temp;
    }
    if (x > z)
    {
        temp = x;
        x = z;
        z = temp;
    }
    if (y > z) 
    {
        temp = y;
        y = z;
        z = temp;
    }
    cout <<"Ba so theo thu tu tang dan la: "<< x << " " << y << " " << z;
}
#include<iostream>
#include<cmath>
using namespace std;
int Tong(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int kq = Tong(n);
	cout << "Tong la :" << kq;
	return 1;
}
int Tong(int k)
{
	int s = 0;
	for (int i = 1; i <= k; i++)
		s = s + i * (i+1);
	return s;
}
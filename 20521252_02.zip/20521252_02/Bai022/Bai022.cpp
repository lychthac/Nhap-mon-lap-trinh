#include<iostream>
#include<cmath>
using namespace std;
int SoHangDonVi(int);
int main()
{
	int n;
	cout << "Nhap n: ";
	cin >> n;
	int kq = SoHangDonVi(n);
	cout << "Chu so hang don vi la: " << kq;
	return 0;
}
int SoHangDonVi(int a)
{
	int dv = a % 10;
	return dv;
}
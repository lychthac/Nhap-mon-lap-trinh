#include <iostream>
using namespace std;
int ktHoanThien(int);
int main()
{
    int n;
    cout << "nhap n=";
    cin >> n;
    int kq = ktHoanThien(n);
    if (kq==1)
        cout << "la so hoan thien";
    else
        cout << "khong la so hoan thien";
    return 0;
}
int ktHoanThien(int x)
{
    long S = 0;
    int i = 1;
    while (i < x )
    {
        if (x % i == 0)
            S = S + i;
        i = i + 1;
    }
    if (S == x)
        return 1;
    else
        return 0;
}

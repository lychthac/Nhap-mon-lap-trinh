#include<iostream>
#include<cmath>
using namespace std;
float Luythua(float,int);
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = Luythua(x,n);
	cout << "Luythua la :" << kq;
	return 1;
}
float Luythua(float y,int k)
{
	float t = 1;
	for (int i = 1; i <= k; i++)
		t = t * y;
	return t;
}

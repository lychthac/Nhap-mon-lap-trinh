#include <iostream>
#include <cmath>
using namespace std;
float Tong(float, int);
int main()
{
	int n;
	float x;
	cout << "Nhap x: ";
	cin >> x;
	cout << "nhap n :";
	cin >> n;
	float kq = Tong(x, n);
	cout << "ket qua la : " << kq;
	return 1;
}
float Tong(float y, int k)
{
	float t = 1;
	int m = 1;
	float s = 0;
	for (int i = 1; i <= k; i++)
	{
		t = t * y;
		m = m * i;
		s = s + (float)t / m;
	}
	return s;
}
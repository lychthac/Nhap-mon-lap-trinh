#include <iostream>
#include <cmath>
using namespace std;
int NhoNhat(int);
int main()
{
	int n;
	cout << "Nhap n : ";
	cin >> n;
	int kq = NhoNhat(n);
	cout << "chu so nho nhat la : " << kq;
	return 1;
}
int NhoNhat(int k)
{
	int min = 9;
	for (int t = k; t != 0; t = t / 10)
	{
		int m = t % 10;
		if (m < min)
			min = m;
	}
	return min;
}
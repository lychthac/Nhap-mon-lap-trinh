#include<iostream>
#include<cmath>
using namespace std;
float TinhGiaTri(float);

int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float kq = TinhGiaTri(x);
	cout << "gia tri cua ham so f(x) la: " << kq;
	return 1;
}

float TinhGiaTri(float k)
{
	float f;
	if (k >= 0)

	{
		if (k <= 1)
			f = 5 * k - 7;
		else
			f = 2 * k * k * k + 5 * k * k - 8 * k + 3;
	}
	else
		f = -2 * k * k * k + 6 * k + 9;
	return f;

}
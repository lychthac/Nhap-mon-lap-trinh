#include<iostream>
#include<cmath>
using namespace std;
float DienTich(float, int);
int main()
{
	float r;
	cout << "Nhap ban kinh r: ";
	cin >> r;
	int n;
	cout << "Nhap so canh cua da giac deu: ";
	cin >> n;
	float kq = DienTich(r, n);
	cout << "Dien tich da giac deu noi tiep hinh tron la: " << kq;
	return 0;
}
float DienTich(float a, int b)
{
	float p = (float)1 / 2 * b * pow(a, 2) * sin(2 * 3.14 / b);
	return p;
}
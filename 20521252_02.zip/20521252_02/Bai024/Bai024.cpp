#include<iostream>
#include<cmath>
using namespace std;
void SoHangTram(int&);
int main()
{
	int n;
	cout << "Nhap n: ";
	cin >> n;
	SoHangTram(n);
	cout << "Chu so hang tram la: " << n;
	return 0;
}
void SoHangTram(int& a)
{
	a = (a / 100) % 10;
}
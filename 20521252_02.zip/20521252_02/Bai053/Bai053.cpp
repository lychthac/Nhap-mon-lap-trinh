#include<iostream>
#include<cmath>
using namespace std;
void LietKeUocLe(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	LietKeUocLe(n);
	return 1;
}
float LietKeUocLe(int k)
{
	int t = k;
	for (int i = 1; i <= k; i=i+2)
	{
		if (t % i == 0)
			cout << i << " ";
	}
	return 1;
}
#include <iostream>
#include <cmath>
using namespace std;
int TonTaiLe(int);
int main()
{
	int n;
	cout << "Nhap n : ";
	cin >> n;
	int kq = TonTaiLe(n);
	if (kq == 1)
		cout << "ton tai chu so le";
	else
		cout << "khong ton tai";
	return 1;
}
int TonTaiLe(int k)
{
	int flag = 0;
	for (int t = k; t != 0; t = t / 10)
	{
		int dv = t % 10;
		if (dv % 2 != 0)
			flag = 1;
	}
	return flag;
}
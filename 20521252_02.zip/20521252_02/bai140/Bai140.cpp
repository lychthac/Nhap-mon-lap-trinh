#include <iostream>
#include <cmath>
using namespace std;
int GiaiPhuongTrinh(float, float, float);
float x1, x2, d;
int main()
{
	float x, y, z;
	cout << "nhap he so a,b,c: ";
	cin >> x >> y >> z;
	d = x * x - 4 * y * z;
	switch (GiaiPhuongTrinh(x, y, z))
	{
	case 0: cout << "pt vo nghiem";
		break;
	case 1: cout << "pt co vo so nghiem";
		break;
	case 2: cout << "pt co mot nghiem: x = " << -y / z;
		break;
	case 3: cout << "pt co nghiem kep: x1 = x2 = " << -y / (2 * x);
		break;
	case 4: cout << "pt co hai nghiem phan biet: x1 = " << (-y + sqrt(d)) / (2 * x) << "; x2 = " << (-y + sqrt(d)) / (2 * x);
		break;
	default:
		break;
	}
}
int GiaiPhuongTrinh(float a, float b, float c)
{
	if (a == 0)
		if (b == 0)
			if (c == 0)
				return 1;
			else
				return 0;
		else
			return 2;
	else
		if (d >= 0)
			if (d > 0)
				return 4;
			else
				return 3;
		else
			return 0;
}

#include <iostream>
#include <cmath>
using namespace std;
int GiaiPhuongTrinh(float, float);
int main()
{
    float an, bn;
    cout << " Nhap vao hai gia tri a va b la : " << endl;
    cin >> an >> bn;
    switch (GiaiPhuongTrinh(an, bn))
    {
    case -1: cout << "pt co vo so nghiem";
        break;
    case 0: cout << "pt vo nghiem";
        break;
    case 1: cout << "pt co nghiem la: x = " << -bn / an;
        break;
    default:
        break;
    }
    return 0;
}
int GiaiPhuongTrinh(float a, float b)
{
    if (a == 0)
        if (b == 0)
            return -1;
        else
            return 0;
    else
        return 1;
}
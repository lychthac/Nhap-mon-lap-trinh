#include <iostream>
using namespace std;
int ktDaoNguoc(int);
int main()
{
    int n;
    cin >> n;
    int kq = ktDaoNguoc(n);
    cout << "so dao nguoc cua " << n << " la: " << kq;
}
int ktDaoNguoc(int k)
{
    int dn = 0;
    int t = k;
    int dv = 0;
    while (t != 0)
    {
        dv = t % 10;
        dn = dn * 10 + dv;
        t = t / 10;
    }
    return dn;
}
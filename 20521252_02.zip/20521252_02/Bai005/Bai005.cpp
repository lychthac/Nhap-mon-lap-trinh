#include <iostream>
#include <cmath>
using namespace std;
float TheTich(float);
int main()
{
	float r;
	cout << "Nhap ban kinh r: ";
	cin >> r;
	float kq = TheTich(r);
	cout << "The tich cua hinh cau la: " << kq;
	return 0;
}
float TheTich(float n)
{
	float s = (float)4 / 3 * 3.14 * pow(n, 3);
	return s;
}
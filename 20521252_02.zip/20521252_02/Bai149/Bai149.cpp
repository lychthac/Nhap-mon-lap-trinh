#include <iostream>
using namespace std;
int ucln(int, int);
int main()
{
    int a, b;
    cout << "nhap a,b lan luot la: ";
    cin >> a >> b;
    cout << "uoc chung lon nhat la: " << ucln(a, b);
    return 0;
}
int ucln(int x, int y)
{
    while (x * y != 0)
    {
        if (x > y)
            x = x - y;
        else 
            y = y - x;
    }
    int s = x + y;
    return s;
}

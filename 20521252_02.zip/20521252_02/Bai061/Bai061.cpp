#include <iostream>
#include <cmath>
using namespace std;
int DemChuSo(int);
int main()
{
	int n;
	cout << "Nhap n : ";
	cin >> n;
	int kq = DemChuSo(n);
	cout << "so luong chu so le la :" << kq;
	return 1;
}
int DemChuSo(int k)
{
	int s = 0;
	for (int t = k; t != 0; t=t/10)
	{
		int m = t % 10;
		if (m % 2 != 0)
			s = s + 1;
	}
	return s;
}


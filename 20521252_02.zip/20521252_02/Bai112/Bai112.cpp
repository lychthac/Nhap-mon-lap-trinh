#include<iostream>
#include<cmath>
using namespace std;
float Tong();
int main()
{
	float kq = Tong();
	cout << "pi = " << kq;
	return 1;
}
float Tong()
{
	float s = 4 - (float)2 / 4 - (float)1 / 5 - (float)1 / 6;
	float t = 1;
	int i = 1;
	for (float e = 1; e >= pow(10, -6); i++)
	{
		t = (float)t / 16;
		e = t * ((float)4 / (8 * i + 1) - (float)2 / (8 * i + 4) - (float)1 / (8 * i + 5) - (float)1 / (8 * i + 6));
		s = s + e;
	}
	return s;
}
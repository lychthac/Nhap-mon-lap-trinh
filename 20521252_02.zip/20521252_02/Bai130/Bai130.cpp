#include <iostream>
#include <cmath>
using namespace std;
int ktTonTai(float, float, float);
int main()
{
    float x, y, z;
    cout << " Nhap vao gia tri x, y, z lan luot la : ";
    cin >> x >> y >> z;
    int kq = ktTonTai(x, y, z);
    if (kq == 1)
        cout << "ton tai tam giac";
    else
        cout << "khong ton tai tam giac";
    return 1;
}
int ktTonTai(float a, float b, float c)
{
    int d;
    if (a + b > c && a + c > b && b + c > a) 
        d = 1;
    else
        d = 0;
    return d;
}

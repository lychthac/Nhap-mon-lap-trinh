#include <iostream>
#include <cmath>
using namespace std;
int TichChuSo(int);
int main()
{
	int n;
	cout << "Nhap n = ";
	cin >> n;
	int kq = TichChuSo(n);
	cout << "tich cac chu so la : " << TichChuSo(n);
	return 1;
}
int TichChuSo(int k)
{
	int s = 1;
	for (int t = k; t != 0; t = t / 10)
	{
		s = s *(t%10);
	}
	return s;
}

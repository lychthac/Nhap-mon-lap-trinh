#include<iostream>
#include<cmath>
using namespace std;
float TinhAn(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = TinhAn(n);
	cout << "so hang thu " << n << " la: " << kq;
	return 1;
}
float TinhAn(int k)
{
	float at = 2;
	float ahh;
	for (int i = 2; i <= k; i++)
	{
		ahh = (float)(at*at+2) / (2*at);
		at = ahh;
	}
	return at;
}
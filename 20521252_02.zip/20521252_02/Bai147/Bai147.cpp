#include <iostream>
using namespace std;
int ktToanLe(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    int kq = ktToanLe(n);
    if (kq==1)
        cout << " Toan le";
    else
        cout << " Khong toan len";
    return 0;
}
int ktToanLe(int k)
{
    int flag = 1;
    for (int t=k;t!=0;t=t/10)
    {
        int dv = t % 10;
        if (dv % 2 == 0)
            flag =0;
    }
    return flag;
}
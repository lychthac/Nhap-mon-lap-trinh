#include<iostream>
#include<cmath>
using namespace std;
int TinhAn(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int kq = TinhAn(n);
	cout << "so hang thu " << n << " la: " << kq;
	return 1;
}
int TinhAn(int k)
{
	int at = -2;
	int t = 3;
	int m = 7;
	int ahh;
	for (int i = 2; i <= k; i++)
	{
		t = t * 3;
		m = m * 7;
		ahh = 5*at + 2 * t -6*m+12;
		at = ahh;
	}
	return at;
}
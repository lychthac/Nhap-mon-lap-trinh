#include <iostream>
#include<cmath>
using namespace std;
int fibo(int);
int main()
{
    int n;
    cout << "Nhap gia tri n la : ";
    cin >> n;
    int kq = fibo(n);
    cout << "So hang thu " <<n<< " cua day la : " << kq;
    return 1;
}
int fibo(int k)
{
    int ftt = 1;
    int ft = 1;
    int fhh;
    int i = 2;
    while (i <= k)
    {
        fhh = ft + ftt;
        ftt = ft;
        ft = fhh;
        i++;
    }
    return fhh;
}
#include<iostream>
#include<cmath>
using namespace std;
float NhietDo(float);
int main()
{
	float f;
	cout << "Nhap do F: ";
	cin >> f;
	float kq = NhietDo(f);
	cout << "Do C la: " << kq;
	return 0;
}
float NhietDo(float a)
{
	float f = (float)5 / 9 * a - 32;
	return f;
}
#include<iostream>
#include<cmath>
using namespace std;
float Tong();
int main()
{
	float kq = Tong();
	cout << "pi = " << kq;
	return 1;
}
float Tong()
{
	float s = 0;
	int dau = 1;
	int i = 0;
	for (float e = 1; e >= pow(10, -6); i++)
	{
		e = (float)4 / (2*i+1);
		s = s + dau*e;
		dau = -dau;
	}
	return s;
}
#include<iostream>
#include<cmath>
using namespace std;
float NhietDo(float);
int main()
{
	float c;
	cout << "Nhap do C = ";
	cin >> c;
	float kq = NhietDo(c);
	cout << "Do C la: " << kq;
	return 0;
}
float NhietDo(float a)
{
	float f = (float)9 / 5 * a + 32;
	return f;
}


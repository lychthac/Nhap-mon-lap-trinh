#include<iostream>
#include<cmath>
using namespace std;
double Tich(float);
int main()
{
	float x;
	cout << "Nhap gia tri cua x: ";
	cin >> x;
	double kq = Tich(x);
	cout << "Ket qua la: " << kq;
	return 0;
}
double Tich(float a)
{
	float a2 = a * a;
	float a4 = a2 * a2;
	float a8 = a4 * a4;
	double a16 = a8 * a8;
	double a32 = a16 * a16;
	return a32;
}
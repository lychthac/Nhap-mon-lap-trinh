#include<iostream>
#include<cmath>
using namespace std;
float Tong( int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = Tong( n);
	cout << "tong la :" << kq;
	return 1;
}
float Tong(int k)
{
	float t = 0;
	float s = 0;
	int dau = 1;
	for (int i = 1; i <= k; i++)
	{
		t = t + i;
		s = s + dau / t;
		dau = -dau;
	}
	return s;
}
#include <iostream>
#include <cmath>
using namespace std;
int TichSoLe(int);
int main()
{
	int n;
	cout << "Nhap n : ";
	cin >> n;
	int kq = TichSoLe(n);
	cout << "tich cac chu so le la :" << kq;
	return 1;
}
int TichSoLe(int k)
{
	int s = 1;
	for (int t = k; t != 0; t = t / 10)
	{
		int m = t % 10;
		if (m % 2 != 0)
			s = s * m;
	}
	return s;
}
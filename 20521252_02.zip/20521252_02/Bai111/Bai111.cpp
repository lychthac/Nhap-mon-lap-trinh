#include<iostream>
#include<cmath>
using namespace std;
float Tong();
int main()
{
	float kq = Tong();
	cout << "pi = " << kq;
	return 1;
}
float Tong()
{
	float s = 3;
	int dau = 1;
	int i = 2;
	for (float e = 1; e >= pow(10, -6); i=i+2)
	{
		e = (float)4 / ((i*(i+1)*(i+2)));
		s = s + dau * e;
		dau = -dau;
	}
	return s;
}
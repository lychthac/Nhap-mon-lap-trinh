#include <iostream>
using namespace std;
int ktDang2n(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    if (ktDang2n(n)==1)
        cout << "co dang 2^m";
    else
        cout << "khong co dang 2^m";
    return 0;
}
int ktDang2n(int k)
{
    int flag = 1;
    for(int t=k;t>1;t=t/2)
    {
        int dv = t % 2;
        if (dv != 0)
            flag = 0;
    }
    return flag;
}

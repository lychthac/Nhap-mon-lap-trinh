#include<iostream>
#include<cmath>
using namespace std;
int ktNhuan(int);
int main()
{
	int n;
	cout << "nhap nam n = ";
	cin >> n;
	int kq = ktNhuan(n);
	if (kq == 1)
		cout << "La nam nhuan";
	else
		cout << "Khong la nam nhuan";
	return 1;
}
int ktNhuan(int k)
{
	if (k % 4 == 0 && k % 100 != 0 || k % 400 == 0)
		return 1;
	else
		return 0;
}
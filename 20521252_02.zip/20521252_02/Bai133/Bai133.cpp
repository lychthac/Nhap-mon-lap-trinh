#include<iostream>
#include<cmath>
using namespace std;
int DinhDang(float, float, float);
int main()
{
	float x, y, z;
	cout << "nhap x, y, z lan luot la ba canh cua tam giac la: ";
	cin >> x >> y >> z;
	switch (DinhDang(x, y, z))
	{
	case 0: cout << "Khong la tam giac";
		break;
	case 1: cout << "La tam giac deu";
		break;
	case 2: cout << "La tam giac vuong can ";
		break;
	case 3: cout << "La tam giac vuong";
		break;
	case 4: cout << "La tam giac can ";
		break;
	case 5: cout << "La tam giac thuong";
	default:
		break;
	}
}
int DinhDang(float a, float b, float c)
{
	if (a + b > c && b + c > a && a + c > b)
	{
		if (a == b && b == c)
			return 1;
		else
		{
			if (a * a + b * b == c * c || b * b + c * c == a * a || a * a + c * c == b * b)
			{
				if (a == b || b == c || a == c)
					return 2;
				else
					return 3;
			}
			else
			{
				if (a == b || b == c || a == c)
					return 4;
				else
					return 5;
			}
		}
	}
	else
		return 0;
}
#include <iostream>
#include <cmath>
using namespace std;
float ChuVi(float);
int main()
{
	float r;
	cout << "Nhap ban kinh r: ";
	cin >> r;
	float kq = ChuVi(r);
	cout << "Chu vi duong tron la: " << kq;
	return 0;
}
float ChuVi(float n)
{
	float p = 2 * 3.14 * n;
	return p;
}
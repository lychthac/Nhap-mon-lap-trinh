#include<iostream>
#include<cmath>
using namespace std;
void LietKektNhuan(int,int);

int main()
{
	int x;
	cout << "nhap x = ";
	cin >> x;
	int y;
	cout << "nhap y = ";
	cin >> y;
	cout << "cac nam nhuan la: ";
	LietKektNhuan(x,y);
	return 1;
}

void LietKektNhuan(int t,int k)
{
	int s;
	for (int i = t; i <= k; i++)
	{
		if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
			cout << i<<" ";
	}
}
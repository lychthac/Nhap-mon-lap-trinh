#include <iostream>
using namespace std;
int ktDoiXung(int);
int main()
{
    int n;
    cout << "nhap n = ";
    cin >> n;
    int kq = ktDoiXung(n);
    if (kq == 1)
        cout << n << " la so dao nguoc";
    else
        cout << n << " khong la so dao nguoc";
    return 0;
}
int ktDoiXung(int k)
{
    int dn = 0;
    int t = k;
    while (t != 0)
    {
        int dv = t % 10;
        dn = dn * 10 + dv;
        t = t / 10;
    }
    if (dn == k)
        return 1;
    else
        return 0;
}
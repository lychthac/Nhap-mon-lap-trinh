#include<iostream>
#include<cmath>
using namespace std;
void Nhap(float&, float&, float&, float&, float&, float&);
float KhoangCach(float, float, float, float);
float ktTonTai(float, float, float);
int main()
{
	float xA, yA, xB, yB, xC, yC;
	Nhap(xA, yA, xB, yB, xC, yC);
	float kc1= KhoangCach( xA, yA, xB, yB);
	float kc2 = KhoangCach( xB, yB, xC, yC);
	float kc3 = KhoangCach( xA, yA, xC, yC);
	float kq=ktTonTai(kc1, kc2, kc3);
	if (kq == 1)
		cout << "la tam giac";
	else
		cout << "khong la tam giac";
	return 1;
}
float KhoangCach(float a, float b, float c, float d)
{
	return sqrt((a - c) * (a - c) + (b - d) * (b - d));
}
float ktTonTai(float a, float b, float c)
{
	if (a + b > c && a + c > b && b + c > a)
		return 1;
	else
		return 0;
}
void Nhap(float& x1, float& y1, float& x2, float& y2, float& x3, float& y3)
{
	cout << "nhap xA = ";
	cin >> x1;
	cout << "nhap yA = ";
	cin >> y1;
	cout << "nhap xB = ";
	cin >> x2;
	cout << "nhap yB = ";
	cin >> y2;
	cout << "nhap xC = ";
	cin >> x3;
	cout << "nhap yC = ";
	cin >> y3;
}
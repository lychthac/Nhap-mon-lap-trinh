#include <iostream>
#include <cmath>
using namespace std;
int BienDoi(int);
int main()
{
    int a, b;
    cout << " Nhap vao gia tri cua a va b lan luot la : ";
    cin >> a >> b;
    int kq1 = BienDoi(a);
    int kq2 = BienDoi(b);
    cout << " Gia tri cua a va b la : " << kq1 << " va " << kq2;
    return 1;
}
int BienDoi(int x)
{
    if (x < 0)
        x = abs(x);
    return x;
}
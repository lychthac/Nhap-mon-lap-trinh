#include<iostream>
#include<cmath>
using namespace std;
float Tong(int);
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float kq = Tong(n);
	cout << "Tong la :" << kq;
	return 1;
}
float Tong(int k)
{
	float s = 0;
	int t = 1;
	for (int i = 1; i <= k; i++)
	{
		t = t * i;
		s = pow(t + s, (float)1 / (i + 1));
	}
	return s;
}
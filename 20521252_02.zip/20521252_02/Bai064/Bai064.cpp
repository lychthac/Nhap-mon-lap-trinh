#include <iostream>
#include <cmath>
using namespace std;
int LonNhat(int);
int main()
{
	int n;
	cout << "Nhap n : ";
	cin >> n;
	int kq = LonNhat(n);
	cout << "chu so lon nhat la : " << kq;
	return 1;
}
int LonNhat(int k)
{
	int max = 0;
	for (int t = k; t != 0; t = t / 10)
	{
		int m = t % 10;
		if (m > max)
			max = m;
	}
	return max;
}
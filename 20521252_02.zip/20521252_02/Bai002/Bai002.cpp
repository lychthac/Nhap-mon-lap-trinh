#include <iostream>
#include <cmath>
using namespace std;
float DienTich(float);
int main()
{
	float r;
	cout << "Nhap ban kinh r: ";
	cin >> r;
	float kq = DienTich(r);
	cout << "Dien tich duong tron la: " << kq;
	return 0;
}
float DienTich(float n)
{
	float s = 3.14 * pow(n, 2);
	return s;
}
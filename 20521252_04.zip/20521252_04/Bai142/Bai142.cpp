#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&, int&);
void Xuat(float[][100], int, int);
void XoaDong(float[][100], int&, int, int);

int main()
{
	float b[100][100];
	int k, l, d;
	Nhap(b, k, l, d);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nMa tran sau khi xoa dong "<<d<<" la: \n";
	XoaDong(b, k, l, d);
	Xuat(b, k, l);
	return 1;
}

void Nhap(float a[][100], int& m, int& n, int& d)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	cout << "Nhap dong can xoa: ";
	cin >> d;
	if (d<0 || d>m - 1)
	{
		cout << "Nhap lai dong can xoa: ";
		cin >> d;
	}
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (201) - 100;
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

void XoaDong(float a[][100], int& m, int n, int d)
{
	for (int j = 0; j < n; j++)
		for (int i = d; i < m - 1; i++)
			a[i][j] = a[i + 1][j];
	m--;
}
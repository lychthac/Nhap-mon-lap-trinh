#include<iostream>
#include<ctime>
#include<cstdlib>
#include<iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
void HoanVi(int&, int&);
void SapCotTang(int[][100], int, int, int);
void SapCotGiam(int[][100], int, int, int);
void SapXep(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;
	int c;
	Nhap(b, k, l);
	cout << "Ma tran ban dau la: \n";
	Xuat(b, k, l);
	cout << "\nMa tran sap cot chan giam, cot le tang: \n";
	SapXep(b, k, l);
	Xuat(b, k, l);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200);
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(9) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

void HoanVi(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

void SapCotTang(int a[][100], int m, int n, int c)
{
	for (int i = 0; i <= m - 2; i++)
		for (int j = i + 1; j <= m - 1; j++)
			if (a[i][c] > a[j][c])
				HoanVi(a[i][c], a[j][c]);
}

void SapCotGiam(int a[][100], int m, int n, int c)
{
	for (int i = 0; i <= m - 2; i++)
		for (int j = i + 1; j <= m - 1; j++)
			if (a[i][c] < a[j][c])
				HoanVi(a[i][c], a[j][c]);
}

void SapXep(int a[][100], int m, int n)
{
	for (int j = 0; j <= n - 1; j++)
	{
		if (j % 2 == 0)
			SapCotGiam(a, m, n, j);
		else
			SapCotTang(a, m, n, j);
	}
}

#include<iostream>
#include<cmath>
#include <ctime>
#include <array>
#include <iomanip>

#define cheochinh(i) cheochinh[i+100] 

using namespace std;

void Nhap(float[][100], int&, int&);
int demMa(float[][100], int, int);
bool ktMa(float[][100], int, int, int, int);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "So con Ma: " << demMa(b, k, l);

}

void Nhap(float a[][100], int& n, int& m)
{
	cout << "Nhap so hang: ";
	cin >> n;
	cout << "Nhap so cot: ";
	cin >> m;

	srand(time(NULL));

	for (int i = 0; i <= n - 1; i++)
		for (int j = 0; j <= m - 1; j++)
			a[i][j] = rand() % (200 + 1) - 100;

	cout << "Ma tran: " << endl;
	for (int i = 0; i <= n - 1; i++)
	{
		for (int j = 0; j <= m - 1; j++)
			cout << setw(4) << a[i][j] << " ";
		cout << endl;
	}
}

int demMa(float a[][100], int n, int m)
{
	int dem = 0;
	for (int i = 0; i <= n - 1; i++)
		for (int j = 0; j <= m - 1; j++)
		{
			if (ktMa(a, n, m, i, j))
			{
				dem++;
				cout << a[i][j] << ": [" << i + 1 << ";" << j + 1 << "]" << ", ";
			}

		}
	return dem;

}

bool ktMa(float a[][100], int n, int m, int x, int y)
{
	//duyet hang
	for (int j = 0; j <= m - 1; j++)
		if (a[x][j] > a[x][y])
			return false;

	//duyet cot
	for (int i = 0; i <= n - 1; i++)
		if (a[i][y] < a[x][y])
			return false;

	return true;
}
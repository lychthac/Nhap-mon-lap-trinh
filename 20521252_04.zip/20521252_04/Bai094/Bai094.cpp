#include <iostream>
#include <ctime>
#include <iomanip>
#include <cstdlib>
using namespace std;
void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int DemLonNhat(int[][100], int, int);
int DemHoanThien(int[][100], int, int, int);
void LietKe(int[][100], int, int);
bool ktHoanThien(int);

int main()
{
	int b[100][100];
	int m, n;
	Nhap(b, m, n);
	cout << "\nMang bat dau la:" << endl;
	Xuat(b, m, n);
	cout << "\nDong co nhieu so hoan thien nhat la: " << endl;
	LietKe(b, m, n);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "nhap m: ";
	cin >> m;
	cout << "\nnhap n: ";
	cin >> n;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			a[i][j] = rand() % (200 + 1) - 100;
		}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(4) << a[i][j];
		cout << "\n";
	}
}

bool ktHoanThien(int n)
{
	int s = 0;
	for (int i = 1; i < n; i++)
		if (n % i == 0)
			s = s + i;
	if (s == n)
		return true;
	else
		return false;
}
int DemHoanThien(int a[][100], int m, int, int d)
{
	int dem = 0;
	for (int j = 0; j < m; j++)
		if (ktHoanThien(a[d][j]))
			dem++;
	return dem;
}
int DemLonNhat(int a[][100], int  m, int n)
{
	int dong = 0;
	int lc = DemHoanThien(a, m, n, 0);
	for (int i = 1; i < m; i++)
		if (DemHoanThien(a, m, n, i) > lc)
		{
			lc = DemHoanThien(a, m, n, i);
			dong = i;
		}
	return dong;
}
void LietKe(int a[][100], int m, int n)
{
	int d = DemLonNhat(a, m, n);
	for (int j = 0; j < n; j++)
		cout << setw(8) << a[d][j];
}

#include<iostream>
#include<ctime>
#include<cstdlib>
#include <iomanip>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int ViTriNhoNhat(int[], int);
int TimChuSo(int[][100], int, int);

int main()
{
	int b[100][100];
	int m, n;
	Nhap(b, m, n);
	cout << "Mang ban dau: ";
	Xuat(b, m, n);
	int kq = TimChuSo(b, m, n);
	cout << "Chu so xuat hien it nhat trong ma tran: " << kq;
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(std::time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			a[i][j] = rand() % 201 - 100;
		}
}

void Xuat(int a[][100], int m, int n)
{
	cout << "\n";
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(6) << a[i][j];
		}
		cout << "\n";
	}
}

int ViTriNhoNhat(int a[], int n)
{
	int lc = 0;
	while (a[lc] == 0)
		lc++;
	for (int i = lc + 1; i < n; i++)
		if (a[i] > 0 && a[i] < a[lc])
			lc = i;
	return lc;
}

int TimChuSo(int a[][100], int m, int n)
{
	int dem[10] = { 0,0,0,0,0,0,0,0,0,0 };
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			if (a[i][j] == 0)
				dem[0]++;
			int t = abs(a[i][j]);
			while (t != 0)
			{
				int dv = t % 10;
				dem[dv]++;
				t = t / 10;
			}
		}
	return ViTriNhoNhat(dem, 10);
}
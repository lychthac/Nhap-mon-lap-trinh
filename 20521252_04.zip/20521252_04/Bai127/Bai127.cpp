#include <iostream>
#include <ctime>
#include <iomanip>
#include <cstdlib>
using namespace std;

void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
void SapDongGiam(int[][100], int, int, int);
void HoanVi(int&, int&);
void SapDongTang(int[][100], int, int, int);
void SapXep(int[][100], int, int);

int main()
{
	int b[100][100];
	int m, n;
	int x;
	Nhap(b, m, n);
	cout << "Ma tran ban dau :\n ";
	Xuat(b, m, n);
	cout << "\nMa tran sap dong chan tang, dong le giam: \n";
	SapXep(b, m, n);
	Xuat(b, m, n);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong :";
	cin >> m;
	cout << "Nhap so cot  :";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(9) << setprecision(3) << a[i][j];
		}
		cout << endl;
		cout << " ";
	}
}

void HoanVi(int& a, int& b)
{
	int temp = a;
	a = b;
	b = temp;
}

void SapDongGiam(int a[][100], int m, int n, int d)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
		{
			if (a[d][i] < a[d][j])
				HoanVi(a[d][i], a[d][j]);
		}
}

void SapDongTang(int a[][100], int m, int n, int d)
{
	for (int i = 0; i < n - 1; i++)
		for (int j = i + 1; j < n; j++)
		{
			if (a[d][i] > a[d][j])
				HoanVi(a[d][i], a[d][j]);
		}
}

void SapXep(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		if (i % 2 == 0)
			SapDongTang(a, m, n, i);
		else
			SapDongGiam(a, m, n, i);
	}
}
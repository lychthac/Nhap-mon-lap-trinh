#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&,int&);
void Xuat(int[][100], int, int);
bool ktToanLe(int);
int DemToanLe(int[][100], int, int, int);

int main()
{
	int b[100][100];
	int k, l, d;
	Nhap(b, k, l, d);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nSo luong so toan le tren dong " << d << " la: " << DemToanLe(b, k, l, d);
	return 1;
}

void Nhap(int a[][100], int& m, int& n, int& d)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	cout << "Nhap dong can xet: ";
	cin >> d;
	if (d<0 || d>n - 1)
	{
		cout << "Nhap lai dong can xet: ";
		cin >> d;
	}
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << "Nhap a[" << i << "][" << j << "] ";
			cin >> a[i][j];
		}
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

int DemToanLe(int a[][100], int m, int n, int d)
{
	int dem = 0;
	for (int j = 0; j < n; j++)
		if (ktToanLe(a[d][j]))
			dem++;
	return dem;
}

bool ktToanLe(int a)
{
	a = abs(a);
	while (a > 0)
	{
		if (a % 2 == 0)
			return false;
		a = a / 10;
	}
	return true;
}
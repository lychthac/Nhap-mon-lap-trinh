
#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);

void LietKe(int[][100], int, int);
int main()
{
	int b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "ma tran ban dau:\n";
	Xuat(b, k, l);
	cout << "cac dong co so toan chan la:";
	LietKe(b, k, l);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "nhap so dong:";
	cin >> m;
	cout << "nhap so cot: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			a[i][j] = (rand() % 201) - 100;
		}

	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(6) << a[i][j];
		}
		cout << endl;
	}
}
int ktDong(int a[][100], int m, int n, int d)
{
	int flag = 1;
	for (int j = 0; j < n; j++)
		if (a[d][j] % 2 != 0)
			flag = 0;
	return flag;
}


void LietKe(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)

		if (ktDong(a, m, n, i) == 1)
			cout << setw(4) << i;
}
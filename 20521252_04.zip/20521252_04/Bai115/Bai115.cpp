#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int ktCot(int[][100], int, int, int);
void LietKe(int[][100], int, int);
bool ktChinhPhuong(int);
int main()
{
	int b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "ma tran ban dau:\n";
	Xuat(b, k, l);
	cout << "cac cot chua so chinh phuong la:";
	LietKe(b, k, l);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "nhap so dong:";
	cin >> m;
	cout << "nhap so cot: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			a[i][j] = (rand() % 201) - 100;
		}

	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(6) << a[i][j];
		}
		cout << endl;
	}
}

int ktCot(int a[][100], int m, int n, int c)
{
	int flag = 0;
	for (int i = 0; i < m; i++)

		if (ktChinhPhuong(a[i][c]))
			flag = 1;
	return flag;
}
void LietKe(int a[][100], int m, int n)
{
	for (int j = 0; j < n; j++)

		if (ktCot(a, m, n, j) == 1)
			cout << setw(4) << j;

}
bool ktChinhPhuong(int k)
{
	bool flag = false;
	for (int i = 0; i <= k; i++)
		if (i * i == k)
			flag = true;
	return flag;


}
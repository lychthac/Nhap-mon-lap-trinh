#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
bool ktToanLe(int);
void LietKe(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nCac gia tri toan le tren bien la: ";
	LietKe(b, k, l);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

bool ktToanLe(int n)
{
	int a = abs(n);
	while (a > 0)
	{
		if (a % 2 == 0)
			return false;
		a = a / 10;
	}
	return true;
}

void LietKe(int a[][100], int m, int n)
{
	for (int j = 0; j < n - 1; j++)
		if(ktToanLe(a[0][j]))
		    cout << setw(6) << a[0][j];
	for (int i = 0; i < m - 1; i++)
		if(ktToanLe(a[i][n - 1]))
		    cout << setw(6) << a[i][n - 1];
	for (int j = n - 1; j > 0; j--)
		if(ktToanLe(a[m - 1][j]))
		    cout << setw(6) << a[m - 1][j];
	for (int i = m - 1; i > 0; i--)
		if(ktToanLe(a[i][0]))
		    cout << setw(6) << a[i][0];
}
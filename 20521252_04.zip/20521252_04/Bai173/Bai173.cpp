#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
float TongCon(float[][100], int, int, int, int, int, int);
void MaTranCon(float[][100], int, int);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nMa tran con co tong lon nhat la: \n";
	MaTranCon(b, k, l);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << "Nhap a[" << i << "][" << j << "] ";
			cin >> a[i][j];
		}
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}

float TongCon(float a[][100], int m, int n, int vtd, int vtc, int k, int h)
{
	float s = 0;
	for (int i = 0; i < k; i++)
		for (int j = 0; j < h; j++)
			s = s + a[vtd + i][vtc + j];
	return s;
}

void MaTranCon(float a[][100], int m, int n)
{
	int c = 0, d = 0, e = 1, f = 1;
	int lc = TongCon(a, m, n, 0, 0, 1, 1);
	for (int k = 1; k <= m; k++)
		for (int h = 1; h <= n; h++)
			for (int i = 0; i <= m - k; i++)
				for (int j = 0; j <= n - h; j++)
					if (TongCon(a, m, n, i, j, k, h) > lc)
					{
						lc = TongCon(a, m, n, i, j, k, h);
						c = i;
						d = j;
						e = k;
						f = h;
					}
	for (int i = 0; i < e; i++)
	{
		for (int j = 0; j < f; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i + c][j + d];
		}
		cout << endl;
	}
}
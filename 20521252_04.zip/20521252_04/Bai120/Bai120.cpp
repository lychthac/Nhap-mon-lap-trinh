#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void Xuat(int[][100], int, int);
void XayDung(float[][100], int, int, int[][100], int&, int&);
int DemLanCan(float[][100], int, int, int, int);

int main()
{
	float a[100][100];
	int b[100][100];
	int k, l, c, d;
	Nhap(a, k, l);
	cout << "ma tran ban dau:\n";
	Xuat(a, k, l);
	XayDung(a, k, l, b, c, d);
	cout << "\nma tran xay dung: \n";
	Xuat(b, c, d);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "nhap so dong:";
	cin >> m;
	cout << "nhap so cot: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << "Nhap a[" << i << "][" << j << "]: ";
			cin >> a[i][j];
		}

	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}

void Xuat(int b[][100], int d, int c)
{
	for (int i = 0; i < d; i++)
	{
		for (int j = 0; j < c; j++)
		{
			cout << setw(7) << b[i][j];
		}
		cout << endl;
	}
}

void XayDung(float a[][100], int m, int n, int b[][100], int& k, int& l)
{
	k = m; l = n;
	for (int i = 0; i < k; i++)
		for (int j = 0; j < l; j++)
			b[i][j] = DemLanCan(a, m, n, i, j);
}

int DemLanCan(float a[][100], int m, int n, int d, int c)
{
	int dem = 0;
	for (int di = -1; di <= 1; di++)
		for (int dj = -1; dj <= 1; dj++)
			if (d + di >= 0 && d + di < m && c + dj >= 0 && c + dj < n && !(di == 0 && dj == 0) && a[d + di][c + dj]>0)
				dem++;
	return dem;
}

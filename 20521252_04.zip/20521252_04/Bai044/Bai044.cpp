#include <iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&, int&);
void Xuat(float[][100], int, int, int);
float TichCot(float[][100], int, int, int);
int main()
{
	float b[100][100];
	int k, l, q;
	Nhap(b, k, l, q);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l, q);
	cout << "Tich la:" << TichCot(b, k, l, q);
	return 1;
}

void Nhap(float a[][100], int& m, int& n, int& c)
{
	cout << "Nhap so dong:";
	cin >> m;
	cout << "Nhap so cot:";
	cin >> n;
	cout << "Nhap c:";
	cin >> c;
	srand(std::time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
		}
}
void Xuat(float a[][100], int m, int n, int c)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(10) << fixed << setprecision(3) << a[i][j];
		}
		cout << endl;
	}
}
float TichCot(float a[][100], int m, int n, int c)
{
	float T = 1;
	for (int i = 0; i < m; i++)
		if (-1 <= a[i][c] && a[i][c] <= 0)
			T = T * a[i][c];
	return T;
}
#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void XayDung(float[][100], int, int, float[][100], int&, int&);
int main()
{
	float a[100][100], b[100][100];
	int k, l, c, d;
	Nhap(b, k, l);
	cout << "ma tran ban dau:\n";
	Xuat(b, k, l);

	XayDung(b, k, l, a, c, d);
	cout << "ma tran xay dung:\n";
	Xuat(a, c, d);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "nhap so dong:";
	cin >> m;
	cout << "nhap so cot: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
		}

	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}
void XayDung(float a[][100], int m, int n, float b[][100], int& k, int& l)
{
	k = m; l = n;
	for (int i = 0; i < k; i++)
		for (int j = 0; j < l; j++)
			b[i][j] = abs(a[i][j]);
}
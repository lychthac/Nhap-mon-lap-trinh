#include <iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&, int&);
void Xuat(float[][100], int, int, int);
float TongDong(float[][100], int, int, int);
int main()
{
	float b[100][100];
	int k, l, q;
	Nhap(b, k, l, q);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l, q);
	cout << "Tong cac gia tri duong tren dong:" << TongDong(b, k, l, q);
	return 1;
}

void Nhap(float a[][100], int& m, int& n, int& d)
{
	cout << "Nhap so dong:";
	cin >> m;
	cout << "Nhap so cot:";
	cin >> n;
	cout << "Nhap d:";
	cin >> d;
	srand(std::time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
		}
}
void Xuat(float a[][100], int m, int n, int d)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(10) << fixed << setprecision(3) << a[i][j];
		}
		cout << endl;
	}
}
float TongDong(float a[][100], int m, int n, int d)
{
	float s = 0;
	for (int j = 0; j < n; j++)
		if (a[d][j] > 0)
			s = s + a[d][j];
	return s;
}
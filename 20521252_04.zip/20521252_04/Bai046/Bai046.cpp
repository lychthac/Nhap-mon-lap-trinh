#include <iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
float TichDuong(float[][100], int, int);
int DemDuong(float[][100], int, int);
float TbnDuong(float[][100], int, int);
int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "Trung binh nhan cac so duong la:" << TbnDuong(b, k, l);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong:";
	cin >> m;
	cout << "Nhap so cot:";
	cin >> n;
	srand(std::time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
		}
}
void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(10) << fixed << setprecision(3) << a[i][j];
		}
		cout << endl;
	}
}
float TichDuong(float a[][100], int m, int n)
{
	float T = 01;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (a[i][j] > 0)
				T = T * a[i][j];
	return T;
}
int DemDuong(float a[][100], int m, int n)
{
	int dem = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (a[i][j] > 0)
				dem++;
	return dem;
}
float TbnDuong(float a[][100], int m, int n)
{
	float tbn, tich = 01;
	int dem = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			if (a[i][j] > 0)
			{
				tich = tich * a[i][j];
				dem = dem + 1;
			}
		}
	if (dem == 0)
		return 1;
	else
	{
		tbn = (float)pow(tich, (float)1 / dem);
		return tbn;
	}
}
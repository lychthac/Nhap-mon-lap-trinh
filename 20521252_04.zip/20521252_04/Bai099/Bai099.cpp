#include<iostream>
#include<iomanip>
#include<ctime>
using namespace std;
void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
void DemChuSo(int, int[]);
int SoLonNhat(int[][100], int, int);

int main()
{
	int k, l;
	int b[100][100];
	Nhap(b, k, l);
	Xuat(b, k, l);

	int x = SoLonNhat(b, k, l);    // de bao la tim 1 chu so xuat hien nhieu nhat, vay coi nhu khong xet truong hop 2 chu so 
								   // co so lan xuat hien bang nhau
	cout << x;
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "nhap so dong ";
	cin >> m;
	cout << "nhap so cot ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (201) - 100;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(6) << a[i][j];
		cout << endl;
	}
	cout << endl;
}

void DemChuSo(int x, int b[])
{
	int temp = abs(x);
	while (temp != 0)
	{
		int dv = temp % 10;
		for (int i = 0; i <= 9; i++)
			if (i == dv)
			{
				int a = b[i];
				a = a + 1;
				b[i] = a;
			}
		temp = temp / 10;
	}
}

int SoLonNhat(int a[][100], int m, int n)
{
	int b[10];
	for (int i = 0; i <= 9; i++)
		b[i] = 0;

	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			DemChuSo(a[i][j], b);

	int lc = 0;
	for (int i = 0; i <= 9; i++)
		if (b[lc] < b[i])
			lc = i;
	return lc;
}



#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
bool ktDuong(float[][100], int, int, int, int);
void TimConToanDuong(float[][100], int, int);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nMa tran con lon nhat toan duong la: \n";
	TimConToanDuong(b, k, l);
	return 1;
}


void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << "Nhap a[" << i << "][" << j << "] ";
			cin >> a[i][j];
		}
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

bool ktDuong(float a[][100], int vtd, int vtc, int k, int h)
{
	for (int i = 0; i < k; i++)
		for (int j = 0; j < h; j++)
			if (a[vtd + i][vtc + j] <= 0)
				return false;
	return true;
}

void TimConToanDuong(float a[][100], int m, int n)
{
	int t = 0;
	int c = 0, d = 0, e = 1, f = 1;
	for (int k = 1; k <= m; k++)
		for (int h = 1; h <= n; h++)
			for (int i = 0; i <= m - k; i++)
				for (int j = 0; j <= n - h; j++)
					if (ktDuong(a, i, j, k, h))
						if (k * h > t)
						{
							t = k * h;
							c = i;
							d = j;
							e = k;
							f = h;
						}
	for (int i = 0; i < e; i++)
	{
		for (int j = 0; j < f; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i + c][j + d];
		}
		cout << endl;
	}
}
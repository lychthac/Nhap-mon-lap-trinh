#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&,int&);
void Xuat(float[][100], int, int);
int ktCotGiam(float[][100], int, int, int);

int main()
{
	float b[100][100];
	int k, l, c;
	Nhap(b, k, l, c);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	if (ktCotGiam(b, k, l, c) == 1)
		cout << "\nCot " << c << " cua ma tran giam";
	else
		cout << "\nCot " << c << " cua ma tran khong giam";
	return 1;
}

void Nhap(float a[][100], int& m, int& n, int& c)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	cout << "Nhap cot can xet: ";
	cin >> c;
	if (c<0 || c>n - 1)
	{
		cout << "Nhap lai cot can xet: ";
		cin >> c;
	}
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}

int ktCotGiam(float a[][100], int m, int n, int c)
{
	for (int i = 0; i < m - 1; i++)
		if (a[i][c] < a[i + 1][c])
			return 0;
	return true;
}
#include<iostream>
#include<ctime>
#include<iomanip>
#include<fstream>
using namespace std;
void Nhap(string,int[][100], int&, int&);
void Xuat(int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;
	string filename = "data01.inp";
	Nhap(filename,b, k, l);
	cout << "Ma tran: \n";
	Xuat(b, k, l);
	return 1;
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

void Nhap(string filename, int a[][100], int& m, int& n)
{
	ifstream myfile(filename);
	myfile>> m;
	myfile >> n;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			myfile >> a[i][j];
}
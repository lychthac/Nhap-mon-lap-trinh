#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&, int& );
void Xuat(int[][100], int, int);
bool ktHoanThien(int);
void LietKe(int[][100], int, int, int);

int main()
{
	int b[100][100];
	int k, l, d;
	Nhap(b, k, l, d);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nCac so hoan thien tren dong " << d << " la: ";
	LietKe(b, k, l, d);
	return 1;
}

void Nhap(int a[][100], int& m, int& n, int& d)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	cout << "Nhap dong can xet: ";
	cin >> d;
	if (d<0 || d>m - 1)
	{
		cout << "Nhap lai dong can xet: ";
		cin >> d;
	}
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

bool ktHoanThien(int n)
{
	int s = 0;
	for (int i = 1; i <= n/2; i++)
		if (n % i == 0)
			s = s + i;
	if (s == n)
		return true;
	else
		return false;
}

void LietKe(int a[][100], int m, int n, int d)
{
	for (int j = 0; j < n; j++)
		if (ktHoanThien(a[d][j]))
			cout << setw(6) << a[d][j];
}
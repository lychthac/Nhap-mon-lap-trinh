#include <iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&, int&);
void Xuat(int[][100], int, int, int);
bool ktChinhPhuong(int);
int TongCot(int[][100], int, int, int);
int main()
{
	int b[100][100];
	int k, l, q;
	Nhap(b, k, l, q);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l, q);
	cout << "Tong cac so chinh phuong tren cot la:" << TongCot(b, k, l, q);

	return 0;
}

void Nhap(int a[][100], int& m, int& n, int& c)
{
	cout << "Nhap so dong:";
	cin >> m;
	cout << "Nhap so cot:";
	cin >> n;
	cout << "Nhap c:";
	cin >> c;
	srand(std::time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			a[i][j] = (rand() % 201) - 100;
		}
}
void Xuat(int a[][100], int m, int n, int c)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(6) << a[i][j];
		}
		cout << endl;
	}
}
bool ktChinhPhuong(int k)
{
	bool flag = false;
	for (int i = 0; i <= k; i++)
		if (i * i == k)
			flag = true;
	return flag;
}
int TongCot(int a[][100], int m, int n, int c)
{
	int s = 0;
	for (int i = 0; i < m; i++)
		if (ktChinhPhuong(a[i][c]))
			s = s + a[i][c];
	return s;
}
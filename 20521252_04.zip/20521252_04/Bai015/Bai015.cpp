#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&, int&);
void Xuat(int[][100], int, int);
void LietKe(int[][100], int, int,int );

int main()
{
	int b[100][100];
	int k, l, d;
	Nhap(b, k, l, d);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nCac gia tri chan tren dong " << d << " la: ";
	LietKe(b, k, l, d);
	return 1;
}

void Nhap(int a[][100], int& m, int& n, int& d)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	cout << "Nhao dong can xet: ";
	cin >> d;
	if (d<0 || d>m - 1)
	{
		cout << "Nhap lai dong can xet: ";
		cin >> d;
	}
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

void LietKe(int a[][100], int m, int n, int d)
{
	for (int j = 0; j < n; j++)
		if (a[d][j] % 2 == 0)
			cout << setw(6) << a[d][j];
}
#include<iostream>
#include<cstdlib>
#include<ctime>
#include<iomanip>
using namespace std;

void Nhap(float[][100], int&, int&, int&, int&);
void Xuat(float[][100], int, int);
void HoanVi(float&, float&);
void HoanViCot(float[][100], int, int, int, int);

int main()
{
	float b[100][100];
	int k, l, c1, c2;
	Nhap(b, k, l, c1, c2);
	cout << "Ma tran ban dau la: \n";
	Xuat(b, k, l);
	cout << "\nMa tran sau khi hoan vi cot "<<c1<<" va "<<c2<<" la: \n";
	HoanViCot(b, k, l, c1, c2);
	Xuat(b, k, l);
	return 1;
}

void Nhap(float a[][100], int& m, int& n, int& x, int& y)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot ";
	cin >> n;
	cout << "Nhap chi so hai cot muon hoan vi: ";
	cin >> x >> y;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setw(7) << setprecision(3) << a[i][j];
		cout << endl;
	}
}

void HoanVi(float& a, float& b)
{
	float temp = a;
	a = b;
	b = temp;
}

void HoanViCot(float a[][100], int m, int n, int c1, int c2)
{
	for (int i = 0; i < m; i++)
		HoanVi(a[i][c1], a[i][c2]);
}
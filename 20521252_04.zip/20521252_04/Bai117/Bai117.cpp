
/*#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
int ktDong(int[][100], int, int, int);
void LietKe(int[][100], int, int);
int main()
{
	int b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "ma tran ban dau:\n";
	Xuat(b, k, l);
	cout << "cac cot tang dan la:";
	LietKe(b, k, l);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "nhap so dong:";
	cin >> m;
	cout << "nhap so cot: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			a[i][j] = (rand() % 201) - 100;
		}

	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(6) << a[i][j];
		}
		cout << endl;
	}
}

int ktDong(int a[][100], int m, int n, int c)
{
	int flag = 1;

	for (int i = 0; i < m; i++)
		if (a[i][c] > a[i+1][c])
			flag = 0;
	return flag;
}

void LietKe(int a[][100], int m, int n)
{
	for (int j = 0; j < n; j++)

		if (ktDong(a, m, n, j) == 1)
			cout << setw(4) << j;
}*/
#include<iostream>
#include<ctime>
#include <iomanip>
using namespace std;

void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
int ktCot(float[][100], int, int, int);
void LietKe(float[][100], int, int);

int main()
{
	float b[100][100];
	int m, n;
	Nhap(b, m, n);
	cout << "Mang ban dau: ";
	Xuat(b, m, n);
	cout << "Cac cot tang dan trong ma tran: ";
	LietKe(b, m, n);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
		{
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
		}
}

void Xuat(float a[][100], int m, int n)
{
	cout << "\n";
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << setprecision(3) << a[i][j];
		}
		cout << "\n";
	}
}

int ktCot(float a[][100], int m, int n, int c)
{
	int flag = 1;
	for (int i = 0; i <= m - 2; i++)
		if (a[i][c] > a[i + 1][c])
			flag = 0;
	return flag;
}

void LietKe(float a[][100], int m, int n)
{
	for (int j = 0; j < n; j++)
		if (ktCot(a, m, n, j) == 1)
			cout << setw(6) << j;
}
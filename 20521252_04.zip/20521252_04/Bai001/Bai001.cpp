#include<iostream>
#include<ctime>
#include<iomanip>
#include<fstream>
using namespace std;
void Nhap(int[][100], int&, int&);
void Xuat(int[][100], int, int);
void Xuat(string, int[][100], int, int);

int main()
{
	int b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau la: \n";
	Xuat(b, k, l);
	string filename = "data01.inp";
	Xuat(filename,b,k,l);
	return 1;
}

void Nhap(int a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

void Xuat(string filename, int a[][100], int m, int n)
{
	ofstream myfile(filename);
	myfile << m << endl;
	myfile << n << endl;
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			myfile << setw(7) << a[i][j];
		}
		myfile << endl;
	}
}
#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
void HoanVi(float&, float&);
void SapTangXoanOc(float[][100], int, int);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nMa tran tang theo hinh xoan oc la: \n";
	SapTangXoanOc(b, k, l);
	Xuat(b, k, l);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}

void HoanVi(float& a, float& b)
{
	float temp = a;
	a = b;
	b = temp;
}

void SapTangXoanOc(float a[][100], int m, int n)
{
	float b[10000];
	int k = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			b[k++] = a[i][j];
	for (int i = 0; i < k - 1; i++)
		for (int j = i + 1; j < k; j++)
			if (b[i] > b[j])
				HoanVi(b[i], b[j]);
	int h = 0;
	int c = 0, c1 = 0, c2 = n - 1, d = 1, d1 = m - 1, d2 = n - 1, e = m - 1, e1 = n - 2, e2 = 0, f = m - 2, f1 = 1, f2 = 0;
	while (h < k)
	{
		for (int j = c1; j <= c2; j++)
			if (h < k)
				a[c][j] = b[h++];
		c++;
		c1++;
		c2--;
		for (int i = d; i <= d1; i++)
			if (h < k)
				a[i][d2] = b[h++];
		d++;
		d1--;
		d2--;
		for (int j = e1; j >= e2; j--)
			if (h < k)
				a[e][j] = b[h++];
		e--;
		e1--;
		e2++;
		for (int i = f; i >= f1; i--)
			if (h < k)
				a[i][f2] = b[h++];
		f--;
		f1++;
		f2++;
	}
}
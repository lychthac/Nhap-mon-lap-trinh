#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(int[][100], int&, int&, int&);
void Xuat(int[][100], int, int);
bool ktDang5m(int);
void LietKe(int[][100], int, int,int );

int main()
{
	int b[100][100];
	int k, l, c;
	Nhap(b, k, l, c);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nCac so nguyen co dang 5m la: ";
	LietKe(b, k, l, c);
	return 1;
}

void Nhap(int a[][100], int& m, int& n, int& c)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	cout << "Nhap cot can xet: ";
	cin >> c;
	if (c<0 || c>n - 1)
	{
		cout << "Nhap lai cot can xet: ";
		cin >> c;
	}
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() % (201) - 100;
	}
}

void Xuat(int a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << a[i][j];
		}
		cout << endl;
	}
}

bool ktDang5m(int a)
{
	if (a <= 0)
		return false;
	while (a > 1)
	{
		if (a % 5 != 0)
			return false;
		else
			a = a / 5;
	}
	return true;
}

void LietKe(int a[][100], int m, int n, int c)
{
	for (int i = 0; i < m; i++)
			if (ktDang5m(a[i][c]))
				cout << setw(6) << a[i][c];
}
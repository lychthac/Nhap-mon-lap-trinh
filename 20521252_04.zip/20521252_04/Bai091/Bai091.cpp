#include <iostream>
#include <ctime>
#include <iomanip>
#include <cstdlib>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
float TongNhoNhat(float[][100], int, int);
float TongCot(float[][100], int, int, int);
void LietKe(float[][100], int, int);

int main()
{
	float b[100][100];
	int m, n;
	Nhap(b, m, n);
	cout << "Ma tran la:" << endl;
	Xuat(b, m, n);
	cout << "Tong cot nho nhat trong ma tran la: " << endl;
	LietKe(b, m, n);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);
		}
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(7) << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}


float TongCot(float a[][100], int m, int n, int d)
{
	float s = 0;
	for (int i = 0; i < m; i++)
		s = s + a[i][d];
	return s;
}

float TongNhoNhat(float a[][100], int m, int n)
{
	float lc = TongCot(a, m, n, 0);
	for (int j = 0; j < n; j++)
		if (TongCot(a, m, n, j) < lc)
			lc = TongCot(a, m, n, j);
	return lc;
}

void LietKe(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (TongCot(a, m, n, j) == TongNhoNhat(a, m, n))
				cout << setw(8) << a[i][j] << endl;
}

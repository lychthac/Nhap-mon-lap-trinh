#include <iostream>
#include <ctime>
#include <iomanip>
#include <cstdlib>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
int DemLonNhat(float[][100], int, int);
float DemCot(float[][100], int, int, int);
void LietKe(float[][100], int, int);
int Dem(int);

int main()
{
	float b[100][100];
	int m, n;
	Nhap(b, m, n);
	cout << "\nMang bat dau la:" << endl;
	Xuat(b, m, n);
	cout << "\nCac cot co nhieu chu so nhat la: " << endl;
	LietKe(b, m, n);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << " Nhap m: ";
	cin >> m;
	cout << " Nhap n: ";
	cin >> n;
	srand(time(NULL));
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			a[i][j] = -100 + rand() / (RAND_MAX / 200.0);

}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			cout << setprecision(2) << setw(8) << a[i][j];
		cout << "\n";
	}
}

int Dem(int n)
{
	int t = n;
	int dem = 0;
	while (t != 0)
	{
		dem++;
		t = t / 10;
	}
	return dem;
}

float DemCot(float a[][100], int m, int n, int c)
{
	int dem = 0;
	for (int i = 0; i < m; i++)
		dem = dem + Dem(a[i][c]);
	return dem;
}

int DemLonNhat(float a[][100], int  m, int n)
{
	int cot = 0;
	float lc = DemCot(a, m, n, 0);
	for (int j = 0; j < n; j++)
		if (DemCot(a, m, n, j) > lc)
		{
			lc = DemCot(a, m, n, j);
			cot = j;
		}
	return cot;
}

void LietKe(float a[][100], int m, int n)
{
	int c = DemLonNhat(a, m, n);
	for (int j = 0; j < n; j++)
	{
		if (DemCot(a, m, n, c) == DemCot(a, m, n, j))
			for (int i = 0; i < m; i++)
				cout << setw(8) << a[i][j] << endl;
		cout << endl;
	}
}

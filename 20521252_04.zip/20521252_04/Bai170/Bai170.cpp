#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
int ktCon(float[][100], int, int, float[][100], int, int);

int main()
{
	float a[100][100],b[100][100];
	int m,n,k, l;
	Nhap(a, m, n);
	Nhap(b, k, l);
	cout << "Ma tran 1 ban dau: \n";
	Xuat(a, m, n);
	cout << "Ma tran 2 ban dau: \n";
	Xuat(b, k, l);
	if (ktCon(a, m, n, b, k, l)==1)
		cout << "\nMa tran 1 la con cua ma tran 2";
	else
		cout << "\nMa tran 1 khong la con cua ma tran 2";
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << "Nhap a[" << i << "][" << j << "] ";
			cin >> a[i][j];
		}
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}

int ktCon(float a[][100], int m, int n, float b[][100], int k, int l)
{
	if (m > k || n > l)
		return 0;
	int flag = 0;
	for(int d=0;d<=k-m;d++)
		for (int c = 0; c <= l - n; c++)
		{
			int co = 1;
			for (int i = 0; i < m; i++)
				for (int j = 0; j < n; j++)
					if (a[i][j] != b[d + i][c + j])
						co = 0;
			if (co == 1)
				flag = 1;
		}
	return flag;
}
#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&, int&);
void Xuat(float[][100], int, int);
void ThemDong(float[][100], int&, int, int);

int main()
{
	float b[100][100];
	int k, l, d;
	Nhap(b, k, l, d);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nMa tran sau khi them dong tai dong " << d << " la: \n";
	ThemDong(b, k, l, d);
	Xuat(b, k, l);
	return 1;
}

void Nhap(float a[][100], int& m, int& n, int& d)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	cout << "Nhap vi tri dong can them vao: ";
	cin >> d;
	if (d<0 || d>m - 1)
	{
		cout << "Nhap lai vi tri dong: ";
		cin >> d;
	}
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}

void ThemDong(float a[][100], int& m, int n, int d)
{
	for (int j = 0; j < n; j++)
	{
		for (int i = m; i > d; i--)
			a[i][j] = a[i - 1][j];
		a[d][j] = 1;
	}
	m++;
}
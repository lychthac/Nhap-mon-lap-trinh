#include<iostream>
#include<ctime>
#include<iomanip>
using namespace std;
void Nhap(float[][100], int&, int&);
void Xuat(float[][100], int, int);
bool LonNhatDong(float[][100],int,int,int,int);
bool LonNhatCot(float[][100], int, int, int, int);
bool LonNhatCheo1(float[][100], int, int, int, int);
bool LonNhatCheo2(float[][100], int, int, int, int);
int DemHoangHau(float[][100], int, int);

int main()
{
	float b[100][100];
	int k, l;
	Nhap(b, k, l);
	cout << "Ma tran ban dau: \n";
	Xuat(b, k, l);
	cout << "\nSo luong gia tri hoang hau la: "<<DemHoangHau(b, k, l);
	return 1;
}

void Nhap(float a[][100], int& m, int& n)
{
	cout << "Nhap so dong: ";
	cin >> m;
	cout << "Nhap so cot: ";
	cin >> n;
	srand(time(nullptr));
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			a[i][j] = rand() / (RAND_MAX / 200.0) - 100.0;
	}
}

void Xuat(float a[][100], int m, int n)
{
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			cout << setw(8) << fixed << setprecision(2) << a[i][j];
		}
		cout << endl;
	}
}

bool LonNhatCheo1(float a[][100],int m,int n,int i,int j)
{
	int k = i - 1;
	int h = j - 1;
	while(k>=0&&h>=0)
	{
		    if (a[k][h] > a[i][j])
			     return false;
			k--;
			h--;
	}
	int c = i + 1;
	int d = j + 1;
	while (c < m&&d<n)
	{
			if (a[c][d] > a[i][j])
				return false;
			c++;
			d++;
	}
	return true;
}

bool LonNhatCheo2(float a[][100], int m, int n, int i, int j)
{
	int k = i - 1;
	int h = j + 1;
	while (k >= 0 && h < n)
	{
		if (a[k][h] > a[i][j])
			return false;
		k--;
		h++;
	}
	int c = i + 1;
	int d = j - 1;
	while (c < m && d >= 0)
	{
		if (a[c][d] > a[i][j])
			return false;
		c++;
		d--;
	}
	return true;
}

bool LonNhatDong(float a[][100], int m, int n, int i, int j)
{
	for (int h = 0; h < n; h++)
		if (a[i][h] > a[i][j])
			return false;
	return true;
}

bool LonNhatCot(float a[][100], int m, int n, int i, int j)
{
	for (int k = 0; k < m; k++)
		if (a[k][j] > a[i][j])
			return false;
	return true;
}

int DemHoangHau(float a[][100], int m, int n)
{
	int dem = 0;
	for (int i = 0; i < m; i++)
		for (int j = 0; j < n; j++)
			if (LonNhatCheo1(a,m,n,i,j) && LonNhatCheo2(a, m, n, i, j) && LonNhatDong(a, m, n, i, j) && LonNhatCot(a, m, n, i, j))
				dem++;
	return dem;
}
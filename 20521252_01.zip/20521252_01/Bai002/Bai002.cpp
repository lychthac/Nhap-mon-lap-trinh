#include<iostream>
using namespace std;
int main()
{
	float r;
	cout << "ban kinh = ";
	cin >> r;
	float dt = 3.14 * r * r;
	cout << "dien tich = " << dt;
	return 1;
}
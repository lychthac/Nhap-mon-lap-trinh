#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int at = 2;
	int i = 2;
	while (i <= n)
	{
		int ahh = at + 2 * i + 1;
		i = i + 1;
		at = ahh;
	}
	cout << "so hang thu " << n << " la " << at;
	return 0;
}
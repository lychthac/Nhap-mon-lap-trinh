#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int s = 1;
	int k = 0;
	while (s * 2 < n)
	{
		k = k + 1;
		s = s * 2;
	}
	cout << "so nguyen K lon nhat la: " << k;
	return 1;
}
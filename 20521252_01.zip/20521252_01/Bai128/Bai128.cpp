#include<iostream>
using namespace std;
int main()
{
	float a, b;
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	while (a > b)
	{
		float temp = a;
		a = b;
		b = temp;
	}
	cout << "gia tri a, b theo thu tu tang dan la " << a<<" va " << b;
	return 1;
}
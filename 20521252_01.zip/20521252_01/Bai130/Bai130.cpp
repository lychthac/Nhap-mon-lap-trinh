#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x, y, z;
	cout << "nhap x, y, z ";
	cin >> x >> y >> z;
	x = abs(x);
	y = abs(y);
	z = abs(z);
	if (x + y > z and y + z > x and x + z > y)
		cout << "la tam giac";
	else
		cout << "khong la tam giac";
	return 0;
}
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int t = abs(n);
	int flag = 1;
	while (t != 0)
	{
		int dv = t % 10;
		if (dv % 2 != 0)
			flag = 0;
		t = t / 10;
	}
	if (flag == 1)
		cout << "la so toan chan";
	else
		cout << "khong toan chan";
	return 0;
}
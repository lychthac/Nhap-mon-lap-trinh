#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "so canh n = ";
	cin >> n;
	float r;
	cout << "ban kinh r = ";
	cin >> r;
	float s =(float) 1 / 2 * n * r * r * sin(M_PI * 2 / n);
	cout << "dien tich = " << s;
	return 0;
}
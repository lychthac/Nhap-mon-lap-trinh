#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float t = 1;
	float m = 1;
	float s = 1;
	float e = 1;
	int i = 1;
	while (e >= pow(10, -6))
	{
		t = t * x;
		m = m * i;
		e = t / m;
		s = s + e;
		i = i + 1;
	}
	cout << "Tong e^x = " << s;
	return 0;
}
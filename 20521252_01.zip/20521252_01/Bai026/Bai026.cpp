#include <iostream>
using namespace std;
int main()
{
	int a, b;
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	a = a + b;
	b = a - b;
	a = a - b;
	cout << "hoan vi gia tri a va b la: " << a <<" va "<< b;
	return 1;
}
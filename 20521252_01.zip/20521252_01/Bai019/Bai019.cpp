#include <iostream>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float x2 = x * x;
	float x3 = x2 * x;
	float x6 = x3 * x3;
	long x12 = x6 * x6;
	long x13 = x * x12;
	cout << "x13 = " << x13;
	return 0;
}
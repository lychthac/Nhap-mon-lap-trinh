#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float s = 0;
	float t = x;
	int i = 1;
	while (i <= n)
	{
		t = sin(t);
		s = s + t;
		i = i + 1;
	}
	cout << "S= " << s;
	return 1;
}
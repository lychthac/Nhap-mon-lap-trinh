#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int att = 1;
	int at =2;
	int i = 2;
	while (i <= n)
	{
		int ahh = 4 * at + att;
		att = at;
		at = ahh;
		i = i + 1;
	}
	cout << "so hang thu " << n << " la " << at;
	return 1;
}
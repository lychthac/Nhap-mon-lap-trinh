#include <iostream>
using namespace std;
int main()
{
	float r;
	cout << "ban kinh r = ";
	cin >> r;
	float s = 4 * 3.14 * r * r;
	cout << "dien tich = " << s;
	return 1;
}
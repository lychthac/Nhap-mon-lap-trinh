#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int a, b;
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	a = abs(a);
	b = abs(b);
	while (a * b != 0)
	{
		if (a > b)
			a = a - b;
		else
			b = b - a;
	}
	int s = a + b;
	cout <<"uoc chung lon nhat la "<< s;
	return 1;
}
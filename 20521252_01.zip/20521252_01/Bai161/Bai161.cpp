#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int flag = 1;
	int t=n;
	while (t != 0)
	{
		int a = t % 10;
		int b = (t / 10) % 10;
		if (a < b)
			flag = 0;
		t = t / 10;
	}
	if (flag == 1)
		cout << n << " tang dan tu trai sang phai";
	else
		cout << n << " khong tang dan";
	return 0;
}
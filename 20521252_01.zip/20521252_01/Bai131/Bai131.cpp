#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float xA, yA, xB, yB, xC, yC;
	cout << "toa do diem A la";
	cin >> xA >> yA;
	cout << "toa do diem B la";
	cin >> xB >> yB;
	cout << "toa do diem C la";
	cin >> xC >> yC;
	float a = sqrt((xA - xB) * (xA - xB) + (yA - yB) * (yA - yB));
	float b = sqrt((xC - xB) * (xC - xB) + (yC - yB) * (yC - yB));
	float c = sqrt((xA - xC) * (xA - xC) + (yA - yC) * (yA - yC));
	if (a + b > c && a + c > b && b + c > a)
		cout << "la tam giac";
	else
		cout << "khong la tam giac";
	return 1;
}
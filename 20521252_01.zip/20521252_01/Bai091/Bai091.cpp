#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	int n;
	cout << "nhap x = ";
	cin >> x;
	cout << "nhap n = ";
	cin >> n;
	float s = -1;
	float t = 1;
	int m = 1;
	int dau = 1;
	int i = 1;
	while (i <= 2 * n )
	{
		t = t * x * x;
		m = m * i * (i + 1);
		s = s + dau * t / m;
		dau = -dau;
		i = i + 2;
	}
	cout << "S = " << s;
	return 0;
}
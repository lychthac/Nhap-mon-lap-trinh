#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int flag = 1;
	int t = abs(n);
	while (t >1)
	{
		int dv = t % 5;
		if (dv != 0)
			flag = 0;
		t = t / 5;
	}
	if (flag == 1)
		cout << "co dang";
	else
		cout << "khong co dang";
	return 1;
}
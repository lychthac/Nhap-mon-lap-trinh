#include<iostream>
using namespace std;
int main()
{
	float a, b, c;
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	cout << "nhap c = ";
	cin >> c;
	float temp;
	while (a > b)
	{
		temp = a;
		a = b;
		b = temp;
	}
	while (a > c)
	{
		temp = a;
		a = c;
		c = temp;
	}
	while (b > c)
	{
		temp = b;
		b = c;
		c = temp;
	}
	cout << "a, b, c theo thu tu tang dan la " << a << " " << b << " " << c;
	return 0;
}
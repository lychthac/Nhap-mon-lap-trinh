#include<iostream>
using namespace std;

int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int s = 0;
	int k = 0;
	while (s+k +k+1 < n)
	{
		s = s +k;
		k = k + 1;
	}
	cout << "gia tri K lon nhat la: " << k;
	return 1;
}
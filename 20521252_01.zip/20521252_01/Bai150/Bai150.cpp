#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int a, b;
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	int m = abs(a);
	int n = abs(b);
	while (a * b != 0)
	{
		if (a > b)
			a = a - b;
		else
			b = b - a;
	}
	int s = abs(m*n)/(a+b);
	cout<<"boi chung nho nhat la " << s;
	return 1;
}
#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int dem = 0;
	int t = n;
	while (t != 0)
	{
		dem = dem + 1;
		t = t / 10;
	}
	cout << "so luong chu so cua " << n << " la " << dem;
	return 0;
}
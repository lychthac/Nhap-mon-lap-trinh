#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float s = 0;
	int t = 0;
	int i = 1;
	while (i <= n)
	{
		t = t + i;
		s = s + (float)1 / t;
		i = i + 1;
	}
	cout << "S = " << s;
	return 0;
}
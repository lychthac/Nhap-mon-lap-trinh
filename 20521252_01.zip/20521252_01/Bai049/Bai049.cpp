#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int i = 1;
	cout << "cac uoc so cua " << n << " la ";
	while (i <= n)
	{
		if (n % i == 0)
			cout << i << " ";
		i = i + 1;
	}
	return 0;
}
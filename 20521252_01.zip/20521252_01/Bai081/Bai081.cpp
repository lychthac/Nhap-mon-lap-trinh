#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float s = 0;
	float m = 1;
	int i = 0;
	while (i <= n)
	{
		m = m * (x+i);
		s = s + (float)1/m;
		i = i + 1;
	}
	cout << "S= " << s;
	return 1;
}
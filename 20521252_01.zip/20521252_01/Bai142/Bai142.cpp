#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int dt = abs(n);
	int dn = 0;
	while (dt != 0)
	{
		int dv = dt % 10;
		dn = dn * 10 + dv;
		dt = dt / 10;
	}
	cout << "so dao nguoc cua "<<n<<" la "<<dn;
	return 0;
}
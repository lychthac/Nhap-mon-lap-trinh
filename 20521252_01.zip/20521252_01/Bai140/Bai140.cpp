#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float a, b, c;
	cout << "nhap a= ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	cout << "nhap c = ";
	cin >> c;
	float t = b * b - 4 * a * c;
	if (t != 0)
	{
		if (t > 0)
		{
			float x1 = (-b + sqrt(t)) / (2 * a);
			float x2 = (-b - sqrt(t)) / (2 * a);
			cout << "phuong trinh co 2 nghiem la " << x1 << " va " << x2;
		}
		else
			cout << "vo nghiem";
	}
	else
	{
		float x = -b / (2 * a);
		cout << "phuong trinh co 1 nghiem kep la " << x;
	}
	return 0;
}
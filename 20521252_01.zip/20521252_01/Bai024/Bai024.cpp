#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	n = abs(n);
	int dt = (n / 100) % 10;
	cout << "chu so hang tram cua " << n << " la " << dt;
	return 1;
}
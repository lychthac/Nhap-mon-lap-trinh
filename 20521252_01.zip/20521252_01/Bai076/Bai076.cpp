#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float s = 1+x;
	float t = x;
	int m = 1;
	int i = 2;
	while (i <= 2*n)
	{
		t = t * x * x;
		m = m * i * (i + 1);
		s = s + t/m;
		i = i + 2;
	}
	cout << "S= " << s;
	return 1;
}
#include <iostream>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	long s = x;
	int i = 0;
	while (i <= n)
	{
			s = s*(x+i);
		i = i + 1;
	}
	cout << "S = " << s;
	return 0;
}
#include <iostream>
using namespace std;
int main()
{
	float C;
	cout << "do C = ";
	cin >> C;
	float F = (float)9 / 5 * C + 32;
	cout << "do F = " << F;
	return 1;
}
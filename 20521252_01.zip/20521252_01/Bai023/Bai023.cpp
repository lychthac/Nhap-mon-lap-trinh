#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	n = abs(n);
	int dt = (n / 10) % 10;
	cout << "chu so hang chuc cua " << n << " la " << dt;
	return 1;
}
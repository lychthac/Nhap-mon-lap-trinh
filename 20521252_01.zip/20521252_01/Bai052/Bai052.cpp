#include <iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int sl = 0;
	int i = 1;
	while (i <= n)
	{
		if (n % i == 0)
			sl = sl + 1;
		i = i + 1;
	}
	cout << "so luong uoc so la: " << sl;
	return 0;
}
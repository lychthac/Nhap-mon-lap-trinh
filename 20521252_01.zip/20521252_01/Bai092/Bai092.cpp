#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	int n;
	cout << "nhap x = ";
	cin >> x;
	cout << "nhap n = ";
	cin >> n;
	float s = 1 - x;
	float t = x;
	int m = 1;
	int dau = 1;
	int i = 2;
	while (i <=2* n+1)
	{
		t = t * x * x;
		m = m * i * (i + 1);
		s = s + dau * t / m;
		dau = -dau;
		i = i + 2;
	}
	cout << "S = " << s;
	return 0;
}
#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int t = n;
	int min = 9;
	int sl = 0;
	while (t != 0)
	{
		int dv = t % 10;
		if (dv <min)
			min = dv;
		t = t / 10;
	}
	t = n;
	while (t != 0)
	{
		int a = t % 10;
		if (a == min)
			sl = sl + 1;
		t = t / 10;
	}
	cout << "so luong chu so nho nhat la: " << sl;
	return 1;
}
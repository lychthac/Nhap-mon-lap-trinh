#include <iostream>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float x2 = x * x;
	float x3 = x2 * x;
	float x4 = x2 * x2;
	long x7 = x3 * x4;
	long x14 = x7 * x7;
	cout << "x14 = " << x14;
	return 0;
}
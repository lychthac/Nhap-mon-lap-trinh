#include <iostream>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	float x2 = x * x;
	float x3 = x2 * x;
	float x5 = x2 * x3;
	long x10 = x5 * x5;
	long x15 = x5 * x10;
	cout << "x15 = " << x15;
	return 0;
}
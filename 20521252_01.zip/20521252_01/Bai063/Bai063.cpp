#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int s = 1;
	int t = abs(n);
	while (t != 0)
	{
		int dv = t % 10;
		if (dv %2!=0)
			s = s*dv;
		t = t / 10;
	}
	cout << "tich cac chu so le la: " << s;
	return 0;
}
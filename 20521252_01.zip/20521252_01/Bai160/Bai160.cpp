#include<iostream>
using namespace std;
int main()
{
	int n,dv;
	cout << "nhap n = ";
	cin >> n;
	int t = n;
	int sl = 0;
	while (t != 0)
	{
		dv = t % 10;
		t = t / 10;
	}
	t = n;
	while (t != 0)
	{
		int a = t % 10;
		if (a == dv)
			sl = sl + 1;
	    t = t / 10;
	}
	cout << "so luong chu so dau tien la: " << sl;
	return 1;
}
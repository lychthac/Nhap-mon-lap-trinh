#include<iostream>
using namespace std;
int main()
{
	float a, b;
	cout << "nhap a= ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	if (a == 0)
	{
		if (b = 0)
			cout << "vo so nghiem ";
		else
			cout << "vo nghiem";
	}
	else
	{
		float x = -b / a;
		cout << "x = " << x;
	}
	return 0;
}
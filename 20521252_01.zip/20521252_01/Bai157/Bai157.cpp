#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	float a=0;
	int i = 1;
	cout << "day gia tri la: ";
	while (i <= n)
	{
		a=a+(float)1/i;
		cout << a << " ";
		i = i + 1;
	}
	return 0;
}
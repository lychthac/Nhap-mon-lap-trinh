#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int ahh = 1;
	int i = 1;
	cout << "day gia tri la: 1 ";
	while (i <= n)
	{
		ahh = ahh * i;
		cout << ahh << " ";
		i = i + 1;
	}
	return 0;
}
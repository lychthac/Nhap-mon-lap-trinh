#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	while (n % 2 == 0)
		n = n / 2;
	cout << "uoc so le lon nhat la: " << n;
	return 0;
}
#include<iostream>
using namespace std;
int main()
{
	float a, b;
	cout << "nhap a = ";
	cin >> a;
	cout << "nhap b = ";
	cin >> b;
	float lc = a;
	while (lc < b)
		lc = b;
	cout << "gia tri lon nhat la " << lc;
	return 1;
}
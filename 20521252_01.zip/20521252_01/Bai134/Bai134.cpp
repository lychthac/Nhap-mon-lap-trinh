#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x, y, z;
	cout << "nhap x, y, z ";
	cin >> x >> y >> z;
	if (x <= y && y <= z)
		cout << "bat dang thuc dung";
	else
		cout << "bat dang thuc sai";
	return 1;
}
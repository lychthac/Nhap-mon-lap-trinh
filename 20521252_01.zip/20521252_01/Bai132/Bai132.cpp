#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float xA, yA, xB, yB, xC, yC, xM, yM;
	cout << "toa do diem A la";
	cin >> xA >> yA;
	cout << "toa do diem B la";
	cin >> xB >> yB;
	cout << "toa do diem C la";
	cin >> xC >> yC;
	cout << "toa do diem M la";
	cin >> xM >> yM;
	float SABC = 1 / 2 * abs(xA * yB + xB * yC + xC * yA - xB * yA - xC * yB - xA * yC);
	float SMAB = 1 / 2 * abs(xM * yA + xA * yB + xB * yM - xA * yM - xB * yA - xM * yB);
	float SMBC = 1 / 2 * abs(xM * yB + xB * yC + xC * yM - xB * yM - xC * yB - xM * yC);
	float SMCA = 1 / 2 * abs(xM * yC + xC * yA + xA * yM - xC * yM - xA * yC - xM * yA);
	float S = SMAB + SMBC + SMCA;
	if (S = SABC)
		cout << "M thuoc tam giac";
	else
		cout << "M khong thuoc tam giac";
	return 1;
}
#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int t = n;
	int max = 0;
	int sl = 0;
	while (t != 0)
	{
		int dv = t % 10;
		if (dv > max)
			max = dv;
		t = t / 10;
	}
	t = n;
	while (t != 0)
	{
		int a = t % 10;
		if (a == max)
			sl = sl + 1;
		t = t / 10;
	}
	cout << "so luong chu so lon nhat la: " << sl;
	return 1;
}
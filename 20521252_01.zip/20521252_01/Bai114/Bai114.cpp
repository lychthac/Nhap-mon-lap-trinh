#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int at = -2;
	int t = 3;
	int p = 7;
	int i = 2;
	while (i <= n)
	{
		t = t * 3;
		p = p * 7;
		int ahh = 5 * at + 2 * t - 6 * p + 12;
		i = i + 1;
		at = ahh;
	}
	cout << "so hang thu " << n << " la " << at;
	return 0;
}
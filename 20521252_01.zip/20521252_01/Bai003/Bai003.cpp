#include <iostream>
using namespace std;
int main()
{
	float r;
	cout << "ban kinh = ";
	cin >> r;
	float p = 2 * 3.14 * r;
	cout << "chu vi = " << p;
	return 1;
}
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float s = 0;
	float t = 1;
	int dau = -1;
	int i = 1;
	while (i <= n)
	{
		t = t * x * x;
		s = s + dau * t;
		i = i + 1;
		dau = -dau;
	}
	cout << "S= " << s;
	return 1;
}
#include <iostream>
using namespace std;
int main()
{
    int x, y;
    cout << " Nhap vao cac nam x va y la : "  ;
    cin >> x >> y;
    int i = x;
    cout << "cac nam nhuan la: ";
    while (i <= y)
    {
        if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
            cout << i<<" ";
        i = i + 1;
    }
    return 0;
}
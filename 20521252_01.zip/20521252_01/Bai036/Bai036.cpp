#include <iostream>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float t = 1;
	int i = 1;
	while (i <= n)
	{
		t = t * x;
		i = i + 1;
	}
	cout << "T = " << t;
	return 0;
}
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x, y, z;
	cout << "nhap 3 canh : ";
	cin >> x>> y>> z;
	if (x + y > z && y + z > x && x + z > y)
	{
		if ( x==y && y==z)
			cout << "la tam giac deu";
		else
		{
			if (x*x+y*y==z*z || y*y+z*z==x*x || x*x+z*z==y*y)
			{
				if (x==y || y==z || x==z )
					cout << "la tam giac vuong can";
				else
					cout << "la tam giac vuong";
			}
			else
			{
				if (x == y || y == z || x == z)
					cout << "la tam giac can";
				else
					cout << "la tam giac thuong";
			}
		}
	}
	else
		cout << "khong la tam giac";
	return 0;
}
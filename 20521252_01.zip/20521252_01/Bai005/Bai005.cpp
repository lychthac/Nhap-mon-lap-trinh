#include <iostream>
using namespace std;
int main()
{
	float r;
	cout << "ban kinh r = ";
	cin >> r;
	float v = (float)4 / 3 * 3.14 * r * r * r;
	cout << "the tich = " << v;
	return 1;
}
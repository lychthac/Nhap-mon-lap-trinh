#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float x;
	cout << "nhap x = ";
	cin >> x;
	int n;
	cout << "nhap n = ";
	cin >> n;
	float s = 1;
	float t = 1;
	int i = 2;
	while (i <= n+1)
	{
		t = t * x;
		s = s + i*t;
		i = i + 1;
	}
	cout << "S= " << s;
	return 1;
}
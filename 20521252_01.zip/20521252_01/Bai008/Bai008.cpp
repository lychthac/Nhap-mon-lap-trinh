#define _USE_MATH_DEFINES
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int n;
	cout << "so canh n = ";
	cin >> n;
	float r;
	cout << "ban kinh r = ";
	cin >> r;
	float p = 2 * n * r * sin(M_PI / n);
	cout << "chu vi = " << p;
	return 1;
}
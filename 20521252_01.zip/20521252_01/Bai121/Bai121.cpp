#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int ftt = 1;
	int ft = 1;
	int i = 2;
	while (i <= n)
	{
		int fhh = ft + ftt;
		ftt = ft;
		ft = fhh;
		i = i + 1;
	}
	cout << "so hang thu " << n << " la " << ft;
	return 1;
}
#include <iostream>
using namespace std;
int main()
{
	float F;
	cout << "do F = ";
	cin >> F;
	float C = (float)5 / 9 * F - 32;
	cout << "do C = " << C;
	return 1;
}
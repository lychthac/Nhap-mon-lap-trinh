#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int s = 1;
	int k = 1;
	while (s*2 < n)
	{
		s = s * 2;
		k = k + 1;
	}
	cout << "so nguyen K nho nhat la: " << k;
	return 1;
}
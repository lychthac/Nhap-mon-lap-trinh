#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int at = 2;
	int bt = 1;
	int i = 2;
	while (i <= n)
	{
		int ahh = at*at+2*bt*bt;
		int bhh = 2*at*bt;
		at = ahh;
		bt = bhh;
		i = i + 1;
	}
	cout << " so hang thu " << n << " la " << at << " va " << bt;
	return 1;
}
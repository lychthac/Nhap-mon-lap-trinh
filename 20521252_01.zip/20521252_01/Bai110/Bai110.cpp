#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	float s = 0;
	float e = 1;
	int dau = 1;
	int i = 0;
	while (e >= pow(10, -6))
	{
		e = (float)4 / (2*i+1);
		s = s + dau * e;
		dau = -dau;
		i = i + 1;
	}
	cout << "pi = " << s;
	return 1;
}
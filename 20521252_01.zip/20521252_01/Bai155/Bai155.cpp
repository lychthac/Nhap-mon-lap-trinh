#include<iostream>
using namespace std;
int main()
{
	int n;
	cout << "nhap n = ";
	cin >> n;
	int ahh = 1;
	int i = 0;
	cout << "day gia tri la: ";
	while (i <= n)
	{
		ahh = ahh * 2;
		cout << ahh<<" ";
		i = i + 1;
	}
	return 0;
}